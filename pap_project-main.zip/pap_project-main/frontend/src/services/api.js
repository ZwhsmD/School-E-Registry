import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const setupInterceptors = (showError) => {
  api.interceptors.response.use(
    (response) => response,
    (error) => {
      let title = "Błąd";
      let message = "Wystąpił nieoczekiwany problem.";

      if (error.response) {
        title = `Błąd ${error.response.status}`;
        if (error.response.data && typeof error.response.data === 'object') {
          message = error.response.data.message || error.response.data.error || JSON.stringify(error.response.data);
        } else if (typeof error.response.data === 'string') {
          message = error.response.data;
        }
      } else {
        message = "Błąd połączenia z serwerem.";
      }

      showError(title, message);
      return Promise.reject(error);
    }
  );
};

export const studentService = {
  getAll: () => api.get('/students'),
  getById: (id) => api.get(`/students/${id}`),
  create: (data) => api.post('/students', data),
  update: (id, data) => api.put(`/students/${id}`, data),
  delete: (id) => api.delete(`/students/${id}`),
  getWithGrades: (groupId, subjectId) =>
    api.get(`/students/group/${groupId}/subject/${subjectId}`),
  getGrades: (studentId) => api.get(`/students/${studentId}/grades`),
};

export const remarkService = {
    getStudentRemarks: (studentId) => api.get(`/remarks/student/${studentId}`),
    create: (remarkData) => api.post('/remarks/add', remarkData)
};

export const teacherService = {
  getSubjects: (teacherId) => api.get(`/teachers/${teacherId}/subjects`),
  getProfile: (id) => api.get(`/teachers/${id}`),
  getClassStudents: (classId) => api.get(`/students/group/${classId}`),
  getAll: () => api.get('/teachers'),
  create: (data) => api.post('/teachers', data),
  delete: (id) => api.delete(`/teachers/${id}`)
};

export const gradeService = {
  saveBatch: (gradesList) => api.post('/grades/batch', gradesList)
};

export const groupService = {
  getAll: () => api.get('/groups'),
  create: (data) => api.post('/groups', data),
  delete: (id) => api.delete(`/groups/${id}`)
};

export const lessonService = {
  getAll: () => api.get('/lessons'),
  create: (data) => api.post('/lessons', data),
};

export const subjectService = {
  getAll: () => api.get('/subjects'),
  getByGroupId: (groupId) => api.get(`/subjects/group/${groupId}`),
  getByTeacherId: (teacherId) => api.get(`/subjects/teacher/${teacherId}`),
  create: (data) => api.post('/subjects', data),
  delete: (id) => api.delete(`/subjects/${id}`),
  checkIfLast: (id) => api.get(`/subjects/${id}/check-last`),
};

export const testService = {
    create: (data) => api.post('/tests', data),
    getAll: () => api.get('/tests'),
    getByGroupId: (groupId) => api.get(`/tests/group/${groupId}`),
    delete: (id) => api.delete(`/tests/${id}`),
};

export const attendanceService = {
    saveBatch: (attendanceList) => api.post('/presence/batch', attendanceList),
    getSummaryByStudentId: (studentId) => api.get(`/presence/student/${studentId}/summary`),
    getByStudentId: (studentId) => api.get(`/presence/student/${studentId}/summary`)
}

export const userService = {
    login: (credentials) => api.post('/users/login', credentials),
    update: (id, data) => api.put(`/users/${id}`, data),
};

export const adminService = {
  getAll: () => api.get('/admins'),
  getById: (id) => api.get(`/admins/${id}`),
  getByUserId: (userId) => api.get(`/admins/user/${userId}`),
};

export const parentService = {
    getAll: () => api.get('/parents'),
    getById: (id) => api.get(`/parents/${id}`),
    getByStudentId: (studentId) => api.get(`/parents/student/${studentId}`),
    create: (data) => api.post('/parents', data),
    delete: (id) => api.delete(`/parents/${id}`),
    getChildrenByUserId: (userId) => api.get(`/parents/user/${userId}/children`),
};

export default api;