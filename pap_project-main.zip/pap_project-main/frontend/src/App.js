import React, { useEffect} from 'react';
import StudentDashboard from './pages/Student/StudentDashboard';
import TeacherDashboard from './pages/Teacher/TeacherDashboard';
import AdministratorView from './pages/Administrator/AdministratorView';
import ParentDashboard from './pages/Parent/ParentDashboard';
import LoginPage from './pages/LoginPage';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { setupInterceptors } from './services/api';
import { useNotification } from './context/NotificationContext';
import './index.css';

const AppContent = () => {
  const { user } = useAuth();
  const { showError } = useNotification();

  useEffect(() => {
    setupInterceptors(showError);
  }, [showError]);

  if (!user) {
    return <LoginPage />;
  }

  if (user.role === 'teacher') return <TeacherDashboard />;
  if (user.role === 'admin' || user.role === 'Admin') return <AdministratorView />;
  if (user.role === 'parent') return <ParentDashboard />;
  return <StudentDashboard />;
};

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppContent />
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;