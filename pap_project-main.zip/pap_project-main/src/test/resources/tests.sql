/* PRE-TEST CLEANUP: Removing data from previous test runs to avoid duplicate key errors */
DELETE FROM users WHERE email IN ('hacker@test.pl', 'temp_user@test.pl', 'bad_user@test.pl', 'new_teacher@test.pl');
DROP VIEW IF EXISTS public_user_info;

/* 1. INTEGRITY TEST: Users Table Constraints
   Description: Try to insert a role not included in the allowed list (Admin, Teacher, Parent, Student).
   Expected result: ERROR: new row for relation "users" violates check constraint "chk_role" */
INSERT INTO users (email, password_hash, role) VALUES ('hacker@test.pl', '123', 'Guest');


/* 2. INTEGRITY TEST: Students Table & Foreign Key Relations
   Description: Try to assign a student to a non-existent group_id (999).
   Expected result: ERROR: insert or update on table "students" violates foreign key constraint "fk_students_group" */
INSERT INTO students (user_id, name, surname, gender, group_id, birth_date, admission_date)
VALUES (1, 'Marek', 'Błąd', 'Male', 999, '2010-01-01', '2025-09-01');


/* 3. FUNCTION TEST: oblicz_srednia_wazona
   Description: Calculate weighted average for student ID 8 and subject ID 3 (English).
   Expected result: A single row with a numeric average (e.g., 5.60). */
SELECT name, surname, oblicz_srednia_wazona(8, 3) AS srednia_ang
FROM students WHERE student_id = 8;


/* 4. FUNCTION TEST: czy_czerwony_pasek
   Description: Verify the 4.75 threshold logic for honor roll (red stripe).
   Expected result: Column "ma_pasek" returning 'tak' or 'nie' for students 7, 8, and 9. */
SELECT name, surname, czy_czerwony_pasek(student_id::INTEGER) AS ma_pasek
FROM students WHERE student_id IN (7, 8, 9);


/* 5. PROCEDURE TEST: usprawiedliw_okres
   Step A: Check number of absences before execution.
   Step B: Execute procedure for student 7.
   Step C: Verify that absences were updated to 'Excused_Absence'. */
SELECT count(*) AS nieobecnosci_przed FROM presence
WHERE student_id = 7 AND type = 'Absence';

CALL usprawiedliw_okres(7, '2026-01-01'::DATE, '2026-01-20'::DATE);

SELECT type, date FROM presence WHERE student_id = 7 AND date <= '2026-01-20';


/* 6. PROCEDURE TEST: promocja_do_klasy
   Step A: Check current graduation date for group 1.
   Step B: Promote the group by 12 months.
   Step C: Verify the updated graduation date. */
SELECT group_id, graduation_date FROM groups WHERE group_id = 1;

CALL promocja_do_klasy(1);

SELECT group_id, graduation_date AS nowa_data FROM groups WHERE group_id = 1;


/* 7. TRIGGER TEST: chk_zakres_oceny
   Description: Try to insert a grade of 7.0 (outside 1-6 scale).
   Expected result: ERROR: Ocena musi byc pomiedzy 1 a 6. */
INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight)
VALUES (7, 1, 1, 7.0, 1);


/* 8. TRIGGER TEST: trg_sprawdz_kolizje_lekcji
   Description: Try to add a lesson for Teacher 1 at a time they are already occupied (Mon 08:00).
   Expected result: ERROR: Nauczyciel ma juz zaplanowana inna lekcje w tym czasie. */
INSERT INTO subjects (lesson_id, teacher_id, group_id, start_time, end_time, day_of_week, room)
VALUES (2, 1, 2, '08:00', '08:45', 'Poniedziałek', '505');


/* 9. JOIN TABLE TEST: students_parents
   Description: Verify the Many-to-Many relationship between students and parents. */
SELECT s.name AS uczen, p.name AS rodzic
FROM students s
JOIN students_parents sp ON s.student_id = sp.student_id
JOIN parents p ON sp.parent_id = p.parent_id;


/* 10. ADVANCED QUERY: Attendance Ranking
   Description: Test complex aggregation and joins to calculate group attendance percentage. */
SELECT
    g.group_sign || g.group_number::TEXT AS klasa,
    COUNT(CASE WHEN p.type = 'Presence' THEN 1 END) AS suma_obecnosci,
    ROUND(AVG(CASE WHEN p.type = 'Presence' THEN 100 ELSE 0 END)::numeric, 2) || '%' AS frekwencja
FROM groups g
JOIN students s ON g.group_id = s.group_id
JOIN presence p ON s.student_id = p.student_id
GROUP BY g.group_id, g.group_sign, g.group_number;


/* 11. VIEW/COMPLEX QUERY: Student Timetable
   Description: Join 4 tables to generate a readable weekly schedule for student 7. */
SELECT sub.day_of_week, sub.start_time, l.name AS przedmiot, t.surname AS nauczyciel
FROM subjects sub
JOIN lessons l ON sub.lesson_id = l.lesson_id
JOIN teachers t ON sub.teacher_id = t.teacher_id
WHERE sub.group_id = (SELECT group_id FROM students WHERE student_id = 7)
ORDER BY CASE day_of_week
    WHEN 'Poniedziałek' THEN 1 WHEN 'Wtorek' THEN 2 WHEN 'Środa' THEN 3
    WHEN 'Czwartek' THEN 4 WHEN 'Piątek' THEN 5 END, sub.start_time;


/* 12. CASCADE DELETE TEST: ON DELETE CASCADE / PROTECT
   Description: Check if the database protects teacher/user when referenced as tutor.
   Expected result: ERROR if referenced, or SUCCESS if ON DELETE CASCADE is set. */
DELETE FROM users WHERE user_id = 2;


/* 13. DATA INTEGRITY: Unique Email Constraint
   Description: Try to insert a user with an email that already exists.
   Expected result: ERROR: duplicate key value violates unique constraint. */
INSERT INTO users (email, password_hash, role)
VALUES ('jkowadlo@pap.com', 'hash123', 'Teacher');


/* 15. COMPLEX AGGREGATION: Subject Averages per Group
   Description: Calculate average grades with proper numeric casting for PostgreSQL. */
SELECT g.group_sign || g.group_number::TEXT AS class, l.name AS subject,
       ROUND(AVG(gr.grade)::numeric, 2) AS avg_subject_grade
FROM groups g
JOIN students s ON g.group_id = s.group_id
JOIN grades gr ON s.student_id = gr.student_id
JOIN lessons l ON gr.lesson_id = l.lesson_id
GROUP BY g.group_id, g.group_sign, g.group_number, l.name
ORDER BY class, avg_subject_grade DESC;


/* 17. ANALYTICAL QUERY: Top 3 Students
   Description: Find top performing students across the school. */
SELECT s.name, s.surname, ROUND(AVG(gr.grade)::numeric, 2) AS gpa
FROM students s
JOIN grades gr ON s.student_id = gr.student_id
GROUP BY s.student_id, s.name, s.surname
ORDER BY gpa DESC
LIMIT 3;


/* 20. TRANSACTION TEST: Rollback simulation
   Description: Test atomicity. One fail should roll back the entire block.
   Expected result: ROLLBACK occurs; 'temp_user' is NOT in the database. */
BEGIN;
INSERT INTO users (email, password_hash, role) VALUES ('temp_user@test.pl', 'pass', 'Student');
INSERT INTO users (email, password_hash, role) VALUES ('bad_user@test.pl', 'pass', 'InvalidRole');
COMMIT;

SELECT * FROM users WHERE email = 'temp_user@test.pl';


/* 21. BUSINESS LOGIC: Overlapping Lessons for a Group
   Description: Try to schedule a second lesson for the same group at the same time. */
INSERT INTO subjects (lesson_id, teacher_id, group_id, start_time, end_time, day_of_week, room)
VALUES (3, 2, 1, '08:00', '08:45', 'Poniedziałek', '102');


/* 22. ANALYTICAL QUERY: Teacher Workload
   Description: Analyze how many lessons are assigned to each teacher. */
SELECT t.surname, COUNT(sub.subject_id) AS total_lessons
FROM teachers t
LEFT JOIN subjects sub ON t.teacher_id = sub.teacher_id
GROUP BY t.teacher_id, t.surname
ORDER BY total_lessons DESC;


/* 23. DATA INTEGRITY: Minimum Age Check
   Description: Try to insert a student with a future birth date.
   Expected result: ERROR: violates check constraint (if defined). */
INSERT INTO students (user_id, name, surname, gender, group_id, birth_date, admission_date)
VALUES (3, 'Future', 'Kid', 'Male', 1, '2030-01-01', '2025-09-01');


/* 24. COMPLEX JOIN: Parent Contact List for a Class
   Description: List all parents' emails for students in group 1. */
SELECT DISTINCT p.name, p.surname, u.email
FROM parents p
JOIN users u ON p.user_id = u.user_id
JOIN students_parents sp ON p.parent_id = sp.parent_id
JOIN students s ON sp.student_id = s.student_id
WHERE s.group_id = 1;


/* 25. AGGREGATION: Presence Percentage per Student
   Description: Calculate individual attendance rates. */
SELECT s.surname,
       ROUND(AVG(CASE WHEN p.type = 'Presence' THEN 100 ELSE 0 END)::numeric, 2) || '%' AS attendance_rate
FROM students s
JOIN presence p ON s.student_id = p.student_id
GROUP BY s.student_id, s.surname;


/* 26. CONSTRAINT TEST: Valid Gender check
   Description: Try to insert an invalid gender value.
   Expected result: ERROR: violates check constraint "chk_gender". */
INSERT INTO students (user_id, name, surname, gender, group_id, birth_date, admission_date)
VALUES (4, 'X', 'Y', 'Other', 1, '2010-01-01', '2025-09-01');


/* 27. DATA CLEANUP: Unused Subjects
   Description: Identify subjects not currently in use in the timetable. */
SELECT name FROM lessons
WHERE lesson_id NOT IN (SELECT DISTINCT lesson_id FROM subjects);


/* 28. STATISTICAL QUERY: Grade Distribution
   Description: Count frequency of each grade in the school. */
SELECT grade, COUNT(*) AS frequency
FROM grades
GROUP BY grade
ORDER BY grade DESC;


/* 29. UPDATE TEST: Bulk Promotion
   Description: Promote teachers from 'Doktor' to 'Profesor'. */
UPDATE teachers SET degree = 'Profesor' WHERE degree = 'Doktor';
SELECT surname, degree FROM teachers;


/* 30. SECURITY TEST: View masking
   Description: Verify that sensitive data can be hidden using a view. */
CREATE VIEW public_user_info AS SELECT email, role FROM users;
SELECT * FROM public_user_info LIMIT 5;