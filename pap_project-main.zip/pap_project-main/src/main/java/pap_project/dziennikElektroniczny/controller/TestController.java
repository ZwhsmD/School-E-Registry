package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import pap_project.dziennikElektroniczny.entity.Test;
import pap_project.dziennikElektroniczny.repository.GroupRepository;
import pap_project.dziennikElektroniczny.repository.TestRepository;
import pap_project.dziennikElektroniczny.repository.LessonRepository;
import java.util.Map;

@RestController
@RequestMapping("/api/tests")
public class TestController {
        private final TestRepository testRepository;
        private final LessonRepository lessonRepository;
        private final GroupRepository groupRepository;

        public TestController(TestRepository testRepository, LessonRepository lessonRepository, GroupRepository groupRepository) {
            this.testRepository = testRepository;
            this.lessonRepository = lessonRepository;
            this.groupRepository = groupRepository;
        }

        @GetMapping
        public List<Test> getAlltests() {
            return testRepository.findAll();
        }

        @GetMapping("/{id}")
        public ResponseEntity<Test> getTestById(@PathVariable Long id) {
            return testRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
        }

        @PostMapping
        public ResponseEntity<?> createTest(@RequestBody Map<String, Object> payload) {
            try {
                Test test = new Test();
                test.setName(payload.get("name").toString());
                test.setTestDate(LocalDate.parse(payload.get("testDate").toString()));

                Long lessonId = Long.valueOf(payload.get("lessonId").toString());
                Long groupId = Long.valueOf(payload.get("groupId").toString());

                test.setLesson(lessonRepository.findById(lessonId).orElseThrow());
                test.setGroup(groupRepository.findById(groupId).orElseThrow());

                return ResponseEntity.ok(testRepository.save(test));
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Błąd: " + e.getMessage());
            }
        }

        @PutMapping("/{id}")
        public ResponseEntity<Test> updateTest(@PathVariable Long id, @RequestBody Test testDetails) {
            return testRepository.findById(id)
            .map(existingTest -> {
                existingTest.setName(testDetails.getName());
                existingTest.setLesson(testDetails.getLesson());
                existingTest.setGroup(testDetails.getGroup());
                existingTest.setTestDate(testDetails.getTestDate());
                return ResponseEntity.ok(testRepository.save(existingTest));
            })
            .orElse(ResponseEntity.notFound().build());
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deleteTest(@PathVariable Long id) {
                return testRepository.findById(id)
                .map(test -> {
                    testRepository.delete(test);
                    return ResponseEntity.ok().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
            }
        @GetMapping("/group/{groupId}")
        public ResponseEntity<List<Test>> getTestsByGroup(@PathVariable Long groupId) {
            return ResponseEntity.ok(testRepository.findByGroupId(groupId));
        }
    }
    