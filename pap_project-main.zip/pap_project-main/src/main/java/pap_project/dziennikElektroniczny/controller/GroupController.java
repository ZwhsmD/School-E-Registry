package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import pap_project.dziennikElektroniczny.entity.Group;
import pap_project.dziennikElektroniczny.entity.Teacher;
import pap_project.dziennikElektroniczny.repository.GroupRepository;
import pap_project.dziennikElektroniczny.repository.TeacherRepository;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import java.util.Map;

@RestController
@RequestMapping("/api/groups")
@CrossOrigin(origins = "http://localhost:3000")
public class GroupController {
    private final GroupRepository groupRepository;
    private final TeacherRepository teacherRepository;
    private final StudentRepository studentRepository;


    public GroupController(GroupRepository groupRepository, TeacherRepository teacherRepository, StudentRepository studentRepository) {
        this.groupRepository = groupRepository;
        this.teacherRepository = teacherRepository;
        this.studentRepository = studentRepository;
    }

    @GetMapping
    public List<Group> getAllGroups() {
        return groupRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Group> getGroupById(@PathVariable Long id) {
        return groupRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }
        @PostMapping
        public ResponseEntity<?> createGroup(@RequestBody Map<String, Object> payload) {
            try {
                Group group = new Group();
                group.setGroupNumber(Long.valueOf(payload.get("groupNumber").toString()));
                group.setGroupSign(payload.get("groupSign").toString());
                group.setEstablishmentDate(LocalDate.parse(payload.get("establishmentDate").toString()));
                group.setGraduationDate(LocalDate.parse(payload.get("graduationDate").toString()));

                Long tutorId = Long.valueOf(payload.get("tutorId").toString());
                
                Teacher tutor = teacherRepository.findById(tutorId)
                    .orElseThrow(() -> new RuntimeException("Nauczyciel o ID " + tutorId + " nie istnieje!"));
                    
                group.setClassTutor(tutor);

                Group savedGroup = groupRepository.save(group);
                return ResponseEntity.ok(savedGroup);
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.badRequest().body("Błąd: " + e.getMessage());
            }
        }

    @PutMapping("/{id}")
    public ResponseEntity<Group> updateGroup(@PathVariable Long id, @RequestBody Group groupDetails) {
        return groupRepository.findById(id)
            .map(existingGroup -> {
                if (groupDetails.getGroupSign() != null)
                    existingGroup.setGroupSign(groupDetails.getGroupSign());

                if (groupDetails.getGroupNumber() != null)
                    existingGroup.setGroupNumber(groupDetails.getGroupNumber());

                if (groupDetails.getClassTutor() != null)
                    existingGroup.setClassTutor(groupDetails.getClassTutor());

                if (groupDetails.getEstablishmentDate() != null)
                    existingGroup.setEstablishmentDate(groupDetails.getEstablishmentDate());

                if (groupDetails.getGraduationDate() != null)
                    existingGroup.setGraduationDate(groupDetails.getGraduationDate());

                return ResponseEntity.ok(groupRepository.save(existingGroup));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteGroup(@PathVariable Long id) {
        return groupRepository.findById(id)
            .map(group -> {
                boolean hasStudents = studentRepository.existsByGroupId(id);

                if (hasStudents) {
                    return ResponseEntity.badRequest()
                        .body("Nie można usunąć grupy: w bazie danych istnieją uczniowie przypisani do tej klasy.");
                }

                groupRepository.delete(group);
                return ResponseEntity.noContent().build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
}
