package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;

import jakarta.transaction.Transactional;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

import pap_project.dziennikElektroniczny.entity.Teacher;
import pap_project.dziennikElektroniczny.entity.User;
import pap_project.dziennikElektroniczny.repository.UserRepository;
import pap_project.dziennikElektroniczny.repository.TeacherRepository;
import pap_project.dziennikElektroniczny.repository.SubjectRepository;
import pap_project.dziennikElektroniczny.repository.GroupRepository;
import java.util.*;
import pap_project.dziennikElektroniczny.entity.Subject;

@RestController
@RequestMapping("/api/teachers")
@CrossOrigin(origins = "http://localhost:3000")
public class TeacherController {
    private final TeacherRepository teacherRepository;
    private final SubjectRepository subjectRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final GroupRepository groupRepository;

    public TeacherController(TeacherRepository teacherRepository, SubjectRepository subjectRepository, UserRepository userRepository, PasswordEncoder passwordEncoder, GroupRepository groupRepository) {
        this.teacherRepository = teacherRepository;
        this.subjectRepository = subjectRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.groupRepository = groupRepository;
    }

    @GetMapping("/{id}/subjects")
    public ResponseEntity<List<Map<String, Object>>> getTeacherSubjects(@PathVariable Long id) {
        try {
            List<Subject> subjects = subjectRepository.findByTeacherId(id);
            Map<Long, Map<String, Object>> grouped = new HashMap<>();

            for (Subject s : subjects) {
                if (s.getLesson() == null || s.getGroup() == null) continue;

                Long lessonId = s.getLesson().getId();
                String lessonName = s.getLesson().getName();

                if (!grouped.containsKey(lessonId)) {
                    Map<String, Object> lessonMap = new HashMap<>();
                    lessonMap.put("id", lessonId);
                    lessonMap.put("name", lessonName);
                    lessonMap.put("classes", new ArrayList<Map<String, Object>>());
                    grouped.put(lessonId, lessonMap);
                }

                List<Map<String, Object>> classes = (List<Map<String, Object>>) grouped.get(lessonId).get("classes");
                
                boolean classExists = classes.stream().anyMatch(c -> c.get("id").equals(s.getGroup().getId()));
                
                if (!classExists) {
                    Map<String, Object> classMap = new HashMap<>();
                    classMap.put("id", s.getGroup().getId());
                    classMap.put("sign", s.getGroup().getGroupSign());
                    classMap.put("number", s.getGroup().getGroupNumber());
                    classMap.put("lessonId", lessonId);
                    classMap.put("subjectId", s.getId());
                    classes.add(classMap);
                }
            }
            return ResponseEntity.ok(new ArrayList<>(grouped.values()));
        } catch (Exception e) {
            e.printStackTrace(); 
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping
    public List<Teacher> getAllteachers() {
        return teacherRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Teacher> getTeacherById(@PathVariable Long id) {
        return teacherRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }

    private String convertPolishChars(String str) {
        if (str == null) return "";
        return str.toLowerCase()
                .replace("ą", "a").replace("ć", "c").replace("ę", "e")
                .replace("ł", "l").replace("ń", "n").replace("ó", "o")
                .replace("ś", "s").replace("ź", "z").replace("ż", "z");
    }

    @PostMapping
    @Transactional
    public ResponseEntity<Teacher> createTeacher(@RequestBody Teacher teacher) {
        String convertedName = convertPolishChars(teacher.getName());
        String convertedSurname = convertPolishChars(teacher.getSurname());
        
        String baseEmail = (convertedName.substring(0, 1) + 
                        (convertedSurname.length() > 7 ? convertedSurname.substring(0, 7) : convertedSurname))
                        .replaceAll("[^a-z]", "");

        String finalEmail = baseEmail + "@pap.com";
        int counter = 1;
        while (userRepository.findByEmail(finalEmail).isPresent()) {
            finalEmail = baseEmail + counter + "@pap.com";
            counter++;
        }

        User newUser = new User();
        newUser.setEmail(finalEmail);
        newUser.setPassword(passwordEncoder.encode("nowehaslo"));
        newUser.setRole("Teacher");
        User savedUser = userRepository.save(newUser);

        teacher.setUser(savedUser);
        return ResponseEntity.ok(teacherRepository.save(teacher));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable Long id, @RequestBody Teacher teacherDetails) {
        return teacherRepository.findById(id)
        .map(existingTeacher -> {
            existingTeacher.setName(teacherDetails.getName());
            existingTeacher.setSurname(teacherDetails.getSurname());
            existingTeacher.setGender(teacherDetails.getGender());
            existingTeacher.setBirthDate(teacherDetails.getBirthDate());
            existingTeacher.setDegree(teacherDetails.getDegree());
            return ResponseEntity.ok(teacherRepository.save(existingTeacher));
        })
        .orElse(ResponseEntity.notFound().build());
        }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<?> deleteTeacher(@PathVariable Long id) {
        if (groupRepository.existsByClassTutorId(id)) {
            return ResponseEntity.status(409).body("Nie można usunąć nauczyciela, który jest wychowawcą grupy.");
        }
        
        if (subjectRepository.existsByTeacherId(id)) {
            return ResponseEntity.status(409).body("Nie można usunąć nauczyciela, który ma przypisane przedmioty w planie lekcji.");
        }

        return teacherRepository.findById(id)
            .map(teacher -> {
                User user = teacher.getUser();
                teacherRepository.delete(teacher);
                if (user != null) {
                    userRepository.delete(user);
                }
                return ResponseEntity.ok().build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
}