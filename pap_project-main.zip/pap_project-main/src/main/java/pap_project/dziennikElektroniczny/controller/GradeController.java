package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import pap_project.dziennikElektroniczny.entity.Grade;
import pap_project.dziennikElektroniczny.repository.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/grades")
public class GradeController {
    private final GradeRepository gradeRepository;
    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final LessonRepository lessonRepository;

    public GradeController(GradeRepository gradeRepository, StudentRepository studentRepository,
                        TeacherRepository teacherRepository, LessonRepository lessonRepository) {
        this.gradeRepository = gradeRepository;
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
        this.lessonRepository = lessonRepository;
    }

    @PostMapping("/batch")
    @Transactional
    public ResponseEntity<?> saveGrades(@RequestBody List<Map<String, Object>> gradesData) {
        try {
            for (Map<String, Object> data : gradesData) {
                Grade grade = new Grade();

                // Pobieranie ID relacji
                Long sId = Long.valueOf(data.get("studentId").toString());
                Long tId = Long.valueOf(data.get("teacherId").toString());
                Long lessonId = Long.valueOf(data.get("lessonId").toString());

                grade.setStudent(studentRepository.findById(sId)
                    .orElseThrow(() -> new RuntimeException("Nie znaleziono studenta: " + sId)));
                grade.setTeacher(teacherRepository.findById(tId)
                    .orElseThrow(() -> new RuntimeException("Nie znaleziono nauczyciela: " + tId)));
                grade.setLesson(lessonRepository.findById(lessonId)
                    .orElseThrow(() -> new RuntimeException("Nie znaleziono lekcji: " + lessonId)));

                // Ustawianie wartości i wagi
                grade.setGrade(Double.valueOf(data.get("value").toString()));
                grade.setWeight(Long.valueOf(data.get("weight").toString()));

                // --- KLUCZOWA POPRAWKA: Zapisywanie opisu ---
                // Pobieramy description z mapy przesłanej przez frontend
                Object descObj = data.get("description");
                if (descObj != null && !descObj.toString().trim().isEmpty()) {
                    grade.setDescription(descObj.toString());
                } else {
                    // Opcjonalny fallback: jeśli opis jest pusty, użyj kategorii
                    Object catObj = data.get("category");
                    if (catObj != null) {
                        grade.setDescription(catObj.toString());
                    }
                }

                gradeRepository.save(grade);
            }
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Błąd serwera: " + e.getMessage());
        }
    }

    @GetMapping
    public List<Grade> getAllGrades() {
        return gradeRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Grade> getGradeById(@PathVariable Long id) {
        return gradeRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Grade createGrade(@RequestBody Grade grade) {
        return gradeRepository.save(grade);
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<Grade> updateGrade(@PathVariable Long id, @RequestBody Grade gradeDetails) {
        return gradeRepository.findById(id)
        .map(existingGrade -> {
            // Aktualizacja podstawowych danych
            existingGrade.setGrade(gradeDetails.getGrade());
            existingGrade.setWeight(gradeDetails.getWeight());
            existingGrade.setDescription(gradeDetails.getDescription()); // Dodano obsługę opisu
            
            // Aktualizacja relacji
            if (gradeDetails.getStudent() != null) existingGrade.setStudent(gradeDetails.getStudent());
            if (gradeDetails.getTeacher() != null) existingGrade.setTeacher(gradeDetails.getTeacher());
            if (gradeDetails.getLesson() != null) existingGrade.setLesson(gradeDetails.getLesson());
            
            return ResponseEntity.ok(gradeRepository.save(existingGrade));
        })
        .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deleteGrade(@PathVariable Long id) {
        return gradeRepository.findById(id)
        .map(grade -> {
            gradeRepository.delete(grade);
            return ResponseEntity.ok().<Void>build();
        })
        .orElse(ResponseEntity.notFound().build());
    }
}