package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import pap_project.dziennikElektroniczny.entity.Parent;
import pap_project.dziennikElektroniczny.entity.Student;
import pap_project.dziennikElektroniczny.entity.StudentParent;
import pap_project.dziennikElektroniczny.entity.User;
import pap_project.dziennikElektroniczny.repository.ParentRepository;
import pap_project.dziennikElektroniczny.repository.StudentParentRepository;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import pap_project.dziennikElektroniczny.repository.UserRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/parents")
public class ParentController {
    private final ParentRepository parentRepository;
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final StudentParentRepository studentParentRepository;
    private final PasswordEncoder passwordEncoder;

    public ParentController(ParentRepository parentRepository,
                            UserRepository userRepository,
                            StudentRepository studentRepository,
                            StudentParentRepository studentParentRepository,
                            PasswordEncoder passwordEncoder) {
        this.parentRepository = parentRepository;
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.studentParentRepository = studentParentRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public List<Parent> getAllParents() {
        return parentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Parent> getParentById(@PathVariable Long id) {
        return parentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    private String convertPolishChars(String str) {
        if (str == null) return "";
        return str.toLowerCase()
                .replace("ą", "a").replace("ć", "c").replace("ę", "e")
                .replace("ł", "l").replace("ń", "n").replace("ó", "o")
                .replace("ś", "s").replace("ź", "z").replace("ż", "z");
    }

    @PostMapping
    @Transactional
    public ResponseEntity<?> createParent(@RequestBody Map<String, Object> payload) {
        Parent parent = new Parent();
        parent.setName((String) payload.get("name"));
        parent.setSurname((String) payload.get("surname"));
        parent.setGender((String) payload.get("gender"));
        parent.setBirthDate(LocalDate.parse((String) payload.get("birthDate")));

        String convertedName = convertPolishChars(parent.getName());
        String convertedSurname = convertPolishChars(parent.getSurname());
        String baseEmail = (convertedName.substring(0, 1) +
                        (convertedSurname.length() > 7 ? convertedSurname.substring(0, 7) : convertedSurname))
                        .replaceAll("[^a-z]", "");
        String finalEmail = baseEmail + ".parent@pap.com";
        int counter = 1;
        while (userRepository.findByEmail(finalEmail).isPresent()) {
            finalEmail = baseEmail + counter + ".parent@pap.com";
            counter++;
        }

        User newUser = new User();
        newUser.setEmail(finalEmail);
        newUser.setPassword(passwordEncoder.encode("nowehaslo"));
        newUser.setRole("Parent");
        User savedUser = userRepository.save(newUser);
        parent.setUser(savedUser);

        Parent savedParent = parentRepository.save(parent);

        List<Integer> studentIds = (List<Integer>) payload.get("studentIds");
        if (studentIds != null) {
            for (Integer studentId : studentIds) {
                studentRepository.findById(Long.valueOf(studentId)).ifPresent(student -> {
                    StudentParent sp = new StudentParent();
                    sp.setParent(savedParent);
                    sp.setStudent(student);
                    studentParentRepository.save(sp);
                });
            }
        }

        return ResponseEntity.ok(savedParent);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Parent> updateParent(@PathVariable Long id, @RequestBody Parent parentDetails) {
        return parentRepository.findById(id)
                .map(existingParent -> {
                    if (parentDetails.getName() != null) existingParent.setName(parentDetails.getName());
                    if (parentDetails.getSurname() != null) existingParent.setSurname(parentDetails.getSurname());
                    if (parentDetails.getGender() != null) existingParent.setGender(parentDetails.getGender());
                    if (parentDetails.getBirthDate() != null) existingParent.setBirthDate(parentDetails.getBirthDate());

                    return ResponseEntity.ok(parentRepository.save(existingParent));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/{userId}/children")
    public ResponseEntity<List<Student>> getChildrenByUserId(@PathVariable Long userId) {
        return parentRepository.findByUserId(userId)
            .map(parent -> {
                List<Student> children = studentParentRepository.findByParentId(parent.getId())
                    .stream()
                    .map(StudentParent::getStudent)
                    .collect(Collectors.toList());
                return ResponseEntity.ok(children);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deleteParent(@PathVariable Long id) {
        return parentRepository.findById(id)
            .map(parent -> {
                parentRepository.delete(parent);
                return ResponseEntity.ok().<Void>build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
}