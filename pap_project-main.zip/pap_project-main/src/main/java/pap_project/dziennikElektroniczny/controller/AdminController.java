package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import jakarta.transaction.Transactional;
import java.util.List;
import pap_project.dziennikElektroniczny.entity.Admin;
import pap_project.dziennikElektroniczny.entity.User;
import pap_project.dziennikElektroniczny.repository.AdminRepository;
import pap_project.dziennikElektroniczny.repository.UserRepository;

@RestController
@RequestMapping("/api/admins")
public class AdminController {
    private final AdminRepository adminRepository;
    private final UserRepository userRepository;

    public AdminController(AdminRepository adminRepository, UserRepository userRepository) {
        this.adminRepository = adminRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Admin> getAdminById(@PathVariable Long id) {
        return adminRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }  

    @GetMapping("/user/{userId}")
    public ResponseEntity<Admin> getAdminByUserId(@PathVariable Long userId) {
        return adminRepository.findByUserId(userId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Admin createAdmin(@RequestBody Admin admin) {
        return adminRepository.save(admin);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin adminDetails) {
        return adminRepository.findById(id)
        .map(existingAdmin -> {
            existingAdmin.setName(adminDetails.getName());
            existingAdmin.setSurname(adminDetails.getSurname());
            return ResponseEntity.ok(adminRepository.save(existingAdmin));
        })
        .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deleteAdmin(@PathVariable Long id) {
        return adminRepository.findById(id)
            .map(admin -> {
                User userToDelete = admin.getUser();
                adminRepository.delete(admin);
                if (userToDelete != null) {
                    userRepository.delete(userToDelete);
                }
                return ResponseEntity.ok().<Void>build();
            })
            .orElse(ResponseEntity.notFound().build());
    }
}
