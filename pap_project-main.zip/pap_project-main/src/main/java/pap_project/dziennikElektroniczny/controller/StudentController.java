package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import pap_project.dziennikElektroniczny.entity.Grade;
import pap_project.dziennikElektroniczny.entity.Student;
import pap_project.dziennikElektroniczny.entity.User;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import pap_project.dziennikElektroniczny.repository.GradeRepository;
import pap_project.dziennikElektroniczny.repository.RemarkRepository;
import pap_project.dziennikElektroniczny.repository.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentRepository studentRepository;
    private final GradeRepository gradeRepository;
    private final RemarkRepository remarkRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public StudentController(StudentRepository studentRepository, GradeRepository gradeRepository, RemarkRepository remarkRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.studentRepository = studentRepository;
        this.gradeRepository = gradeRepository;
        this.remarkRepository = remarkRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/{studentId}/grades")
    public ResponseEntity<Map<String, Object>> getStudentGrades(@PathVariable Long studentId) {
        List<Grade> grades = gradeRepository.findByStudentId(studentId);

        if (grades.isEmpty()) {
            return ResponseEntity.ok(Map.of("subjects", List.of(), "message", "No grades found"));
        }

        Map<Long, List<Grade>> groupedByLessonId = grades.stream()
                .collect(Collectors.groupingBy(g -> g.getLesson().getId()));

        List<Map<String, Object>> subjectsList = groupedByLessonId.entrySet().stream().map(entry -> {
        List<Grade> lessonGrades = entry.getValue();
        String lessonName = lessonGrades.get(0).getLesson().getName();

        double sumWithWeights = lessonGrades.stream()
                .mapToDouble(g -> g.getGrade() * g.getWeight())
                .sum();
        double weightsSum = lessonGrades.stream()
                .mapToLong(Grade::getWeight)
                .sum();
        
        double weightedAverage = weightsSum > 0 ? sumWithWeights / weightsSum : 0.0;

        List<Map<String, Object>> gradesDetails = lessonGrades.stream().map(g -> Map.<String, Object>of(
                "id", g.getId(),
                "grade", g.getGrade(),
                "weight", g.getWeight(),
                "description", g.getDescription() != null ? g.getDescription() : "Brak opisu", // DODANE
                "teacher", g.getTeacher().getName() + " " + g.getTeacher().getSurname()
        )).collect(Collectors.toList());

        return Map.<String, Object>of(
            "lessonId", entry.getKey(),
            "lessonName", lessonName,
            "grades", gradesDetails,
            "weightedAverage", Math.round(weightedAverage * 100.0) / 100.0 // ZMIENIONA NAZWA
        );
    }).collect(Collectors.toList());

        return ResponseEntity.ok(Map.of("subjects", subjectsList));
    }


    @GetMapping("/group/{groupId}/subject/{lessonId}")
    public ResponseEntity<List<Map<String, Object>>> getStudentsWithGradesForLesson(
            @PathVariable Long groupId,
            @PathVariable Long lessonId) {

        System.out.println("Pobieranie uczniów dla grupy: " + groupId + " i lekcji: " + lessonId);

        List<Student> students = studentRepository.findByGroupId(groupId);

        List<Map<String, Object>> response = students.stream().map(student -> {
            List<Double> gradesList = gradeRepository.findByStudentIdAndLessonId(student.getId(), lessonId)
                    .stream()
                    .map(g -> g.getGrade().doubleValue())
                    .collect(Collectors.toList());

            List<Map<String, Object>> remarksList = remarkRepository.findByStudentId(student.getId())
                .stream()
                .map(r -> {
                    String subjectName = "Brak przedmiotu";
                    if (r.getSubject() != null && r.getSubject().getLesson() != null) {
                        subjectName = r.getSubject().getLesson().getName();
                    }

                    return Map.<String, Object>of(
                        "id", r.getId(),
                        "type", r.getType(),
                        "description", r.getDescription(),
                        "date", r.getDate() != null ? r.getDate().toString() : "",
                        "subjectName", subjectName
                    );
                }).collect(Collectors.toList());

            String userEmail = (student.getUser() != null) ? student.getUser().getEmail() : "Brak konta";

            return Map.<String, Object>of(
                "id", student.getId(),
                "firstName", student.getName(),
                "lastName", student.getSurname(),
                "email", userEmail,
                "birthDate", student.getBirthDate() != null ? student.getBirthDate().toString() : "Brak danych",
                "gender", student.getGender() != null ? student.getGender() : "Brak danych",
                "admissionDate", student.getAdmissionDate() != null ? student.getAdmissionDate().toString() : "Brak danych",
                "className", student.getGroup() != null ? (student.getGroup().getGroupNumber() + student.getGroup().getGroupSign()) : "Brak", // DODANE
                "grades", gradesList,
                "remarks", remarksList
            );
        }).collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

    @GetMapping
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @GetMapping("/group/{groupId}")
    public ResponseEntity<List<Student>> getStudentsByGroup(@PathVariable Long groupId) {
        List<Student> students = studentRepository.findByGroupId(groupId);
        return ResponseEntity.ok(students);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        return studentRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }

    private String convertPolishChars(String str) {
        if (str == null) return "";
        return str.toLowerCase()
                .replace("ą", "a").replace("ć", "c").replace("ę", "e")
                .replace("ł", "l").replace("ń", "n").replace("ó", "o")
                .replace("ś", "s").replace("ź", "z").replace("ż", "z");
    }

    @PostMapping
    @Transactional
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        String convertedName = convertPolishChars(student.getName());
        String convertedSurname = convertPolishChars(student.getSurname());

        String baseEmail = (convertedName.substring(0, 1) +
                        (convertedSurname.length() > 7 ? convertedSurname.substring(0, 7) : convertedSurname))
                        .replaceAll("[^a-z]", "");

        String finalEmail = baseEmail + "@pap.com";
        int counter = 1;
        while (userRepository.findByEmail(finalEmail).isPresent()) {
            finalEmail = baseEmail + counter + "@pap.com";
            counter++;
        }

        User newUser = new User();
        newUser.setEmail(finalEmail);
        newUser.setPassword(passwordEncoder.encode("nowehaslo"));
        newUser.setRole("Student");
        User savedUser = userRepository.save(newUser);

        student.setUser(savedUser);
        return ResponseEntity.ok(studentRepository.save(student));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student studentDetails) {
        return studentRepository.findById(id)
            .map(existingStudent -> {
                if (studentDetails.getName() != null) existingStudent.setName(studentDetails.getName());
                if (studentDetails.getSurname() != null) existingStudent.setSurname(studentDetails.getSurname());
                if (studentDetails.getGender() != null) existingStudent.setGender(studentDetails.getGender());
                if (studentDetails.getBirthDate() != null) existingStudent.setBirthDate(studentDetails.getBirthDate());
                if (studentDetails.getAdmissionDate() != null) existingStudent.setAdmissionDate(studentDetails.getAdmissionDate());
                if (studentDetails.getGroup() != null) existingStudent.setGroup(studentDetails.getGroup());

                return ResponseEntity.ok(studentRepository.save(existingStudent));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        return studentRepository.findById(id)
        .map(student -> {
            User userToDelete = student.getUser();
            studentRepository.delete(student);
            userRepository.delete(userToDelete);
            return ResponseEntity.ok().<Void>build();
        })
        .orElse(ResponseEntity.notFound().build());
    }
}