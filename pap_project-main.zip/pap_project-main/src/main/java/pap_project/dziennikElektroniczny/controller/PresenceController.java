package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.stream.Collectors;

import java.util.Map;

import pap_project.dziennikElektroniczny.entity.Presence;
import pap_project.dziennikElektroniczny.repository.PresenceRepository;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import pap_project.dziennikElektroniczny.repository.SubjectRepository;

@RestController
@RequestMapping("/api/presence")
public class PresenceController {
    private final PresenceRepository presenceRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;

    public PresenceController(PresenceRepository presenceRepository, StudentRepository studentRepository, SubjectRepository subjectRepository) {
        this.presenceRepository = presenceRepository;
        this.studentRepository = studentRepository;
        this.subjectRepository = subjectRepository;
    }

    @PostMapping("/batch")
    @org.springframework.transaction.annotation.Transactional
    public ResponseEntity<?> savePresenceBatch(@RequestBody List<Map<String, Object>> presenceData) {
        try {
            List<Presence> presencesToSave = new java.util.ArrayList<>();

            for (Map<String, Object> data : presenceData) {
                Long studentId = Long.valueOf(data.get("studentId").toString());
                Long subjectId = Long.valueOf(data.get("subjectId").toString());
                java.time.LocalDate date = java.time.LocalDate.parse(data.get("date").toString());
                String type = data.get("type").toString();

                Presence presence = presenceRepository.findByStudentIdAndSubjectIdAndDate(studentId, subjectId, date)
                        .orElse(new Presence());

                if (presence.getId() == 0) {
                    presence.setStudent(studentRepository.findById(studentId)
                        .orElseThrow(() -> new RuntimeException("Nie znaleziono studenta " + studentId)));
                    presence.setSubject(subjectRepository.findById(subjectId)
                        .orElseThrow(() -> new RuntimeException("Nie znaleziono przedmiotu " + subjectId)));
                    presence.setDate(date);
                }

                presence.setType(type);
                presencesToSave.add(presence);
            }

            presenceRepository.saveAll(presencesToSave);
            return ResponseEntity.ok().build();
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            return ResponseEntity.status(409).body("Błąd: Obecność została już wcześniej wpisana w innym żądaniu.");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Błąd serwera: " + e.getMessage());
        }
    }

    @GetMapping
    public List<Presence> getAllPresences() {
        return presenceRepository.findAll();
    }

    @GetMapping("/student/{studentId}/summary")
    public ResponseEntity<Map<String, Object>> getStudentPresenceSummary(@PathVariable Long studentId) {
        List<Presence> allPresences = presenceRepository.findAll()
                .stream()
                .filter(p -> p.getStudent().getId() == studentId)
                .collect(Collectors.toList());

        long totalClasses = allPresences.size();
        long presences = allPresences.stream().filter(p -> "Presence".equalsIgnoreCase(p.getType())).count();
        long absences = allPresences.stream().filter(p -> "Absence".equalsIgnoreCase(p.getType())).count();

        List<Map<String, Object>> history = allPresences.stream()
                .filter(p -> "Absence".equalsIgnoreCase(p.getType()))
                .map(p -> Map.<String, Object>of(
                    "id", p.getId(),
                    "date", p.getDate().toString(),
                    "subjectName", p.getSubject().getLesson().getName() 
                ))
                .collect(Collectors.toList());

        Map<String, Object> stats = Map.of(
            "totalClasses", totalClasses,
            "presences", presences,
            "absences", absences
        );

        return ResponseEntity.ok(Map.of(
            "stats", stats,
            "history", history
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Presence> getPresenceById(@PathVariable Long id) {
        return presenceRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Presence createPresence(@RequestBody Presence presence) {
        return presenceRepository.save(presence);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Presence> updatePresence(@PathVariable Long id, @RequestBody Presence presenceDetails) {
        return presenceRepository.findById(id)
            .map(existingPresence -> {
                if (presenceDetails.getType() != null) existingPresence.setType(presenceDetails.getType());
                if (presenceDetails.getDate() != null) existingPresence.setDate(presenceDetails.getDate());
                return ResponseEntity.ok(presenceRepository.save(existingPresence));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePresence(@PathVariable Long id) {
        return presenceRepository.findById(id)
        .map(presence -> {
            presenceRepository.delete(presence);
            return ResponseEntity.ok().<Void>build();
        })
        .orElse(ResponseEntity.notFound().build());
    }
}
