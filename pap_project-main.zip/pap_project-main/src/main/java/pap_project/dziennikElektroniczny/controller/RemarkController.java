package pap_project.dziennikElektroniczny.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pap_project.dziennikElektroniczny.entity.Remark;
import pap_project.dziennikElektroniczny.repository.RemarkRepository;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import pap_project.dziennikElektroniczny.repository.TeacherRepository;
import pap_project.dziennikElektroniczny.repository.SubjectRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/remarks")
@CrossOrigin(origins = "http://localhost:3000")

public class RemarkController {

    private final RemarkRepository remarkRepository;
    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final SubjectRepository subjectRepository;

    public RemarkController(RemarkRepository remarkRepository, StudentRepository studentRepository, TeacherRepository teacherRepository, SubjectRepository subjectRepository) {
        this.remarkRepository = remarkRepository;
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
        this.subjectRepository = subjectRepository;
    }


    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Map<String, Object>>> getRemarksByStudent(@PathVariable Long studentId) {
        List<Remark> remarks = remarkRepository.findByStudentId(studentId);
        List<Map<String, Object>> response = remarks.stream().map(r -> Map.<String, Object>of(
            "id", r.getId(),
            "type", r.getType(),
            "description", r.getDescription(),
            "date", r.getDate() != null ? r.getDate().toString() : "",

            "subjectName", (r.getSubject() != null && r.getSubject().getLesson() != null)
                            ? r.getSubject().getLesson().getName() : "Brak przedmiotu",
            "teacher", r.getTeacher() != null
                        ? r.getTeacher().getName() + " " + r.getTeacher().getSurname() : "Nieznany nauczyciel"
        )).collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

    @GetMapping
    public List<Remark> getAllRemarks() {
        return remarkRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Remark> getRemarkById(@PathVariable Long id) {
        return remarkRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/add")
    public ResponseEntity<?> addRemark(@RequestBody Map<String, Object> payload) {
        try {
            Remark remark = new Remark();
            remark.setStudent(studentRepository.findById(((Number) payload.get("studentId")).longValue()).orElseThrow());
            remark.setTeacher(teacherRepository.findById(((Number) payload.get("teacherId")).longValue()).orElseThrow());
            if (payload.get("subjectId") != null) {
                Long subId = Long.valueOf(payload.get("subjectId").toString());
                remark.setSubject(subjectRepository.findById(subId).orElse(null));
            }
            remark.setType((String) payload.get("type"));
            remark.setDescription((String) payload.get("description"));
            remark.setDate(LocalDate.now());

            remarkRepository.save(remark);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Błąd zapisu uwagi: " + e.getMessage());
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<Remark> updateRemark(@PathVariable Long id, @RequestBody Remark remarkDetails) {
        return remarkRepository.findById(id)
                .map(existingRemark -> {
                    existingRemark.setStudent(remarkDetails.getStudent());
                    existingRemark.setTeacher(remarkDetails.getTeacher());
                    existingRemark.setSubject(remarkDetails.getSubject());
                    existingRemark.setType(remarkDetails.getType());
                    existingRemark.setDescription(remarkDetails.getDescription());
                    existingRemark.setDate(remarkDetails.getDate());
                    return ResponseEntity.ok(remarkRepository.save(existingRemark));
                })
                .orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRemark(@PathVariable Long id) {
        return remarkRepository.findById(id)
                .map(remark -> {
                    remarkRepository.delete(remark);
                    return ResponseEntity.ok().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}