package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import pap_project.dziennikElektroniczny.entity.User;
import pap_project.dziennikElektroniczny.entity.Admin;
import pap_project.dziennikElektroniczny.entity.Student;
import pap_project.dziennikElektroniczny.entity.Teacher;
import pap_project.dziennikElektroniczny.repository.UserRepository;
import pap_project.dziennikElektroniczny.repository.StudentRepository;
import pap_project.dziennikElektroniczny.repository.TeacherRepository;
import pap_project.dziennikElektroniczny.repository.AdminRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final PasswordEncoder passwordEncoder;
    private final AdminRepository adminRepository;

    public UserController(UserRepository userRepository, 
                          StudentRepository studentRepository, 
                          TeacherRepository teacherRepository, 
                          PasswordEncoder passwordEncoder, AdminRepository adminRepository) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
        this.passwordEncoder = passwordEncoder;
        this.adminRepository = adminRepository;
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.status(409).body("User with this email already exists");
        }

        user.setId(null);

        List<String> allowedRoles = List.of("Admin", "Teacher", "Parent", "Student");
        if (!allowedRoles.contains(user.getRole())) {
            return ResponseEntity.badRequest().body("Invalid role. Allowed: " + allowedRoles);
        }

        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        return ResponseEntity.ok(userRepository.save(user));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        return userRepository.findById(id)
            .map(existingUser -> {
                if (userDetails.getEmail() != null) {
                    existingUser.setEmail(userDetails.getEmail());
                }
                if (userDetails.getPassword() != null && !userDetails.getPassword().isEmpty()) {
                    existingUser.setPassword(passwordEncoder.encode(userDetails.getPassword()));
                }
                if (userDetails.getRole() != null) {
                    existingUser.setRole(userDetails.getRole());
                }

                return ResponseEntity.ok((Object) userRepository.save(existingUser));
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginDetails) {
        return userRepository.findByEmail(loginDetails.getEmail())
            .map(user -> {
                if (passwordEncoder.matches(loginDetails.getPassword(), user.getPassword())) {
                    
                    Map<String, Object> response = new HashMap<>();
                    response.put("email", user.getEmail());
                    response.put("role", user.getRole().toLowerCase());
                    
                    // USTAWIAMY JEDNOZNACZNE NAZWY:
                    response.put("userId", user.getId()); // To zawsze będzie techniczne ID z tabeli users

                    if ("Admin".equalsIgnoreCase(user.getRole())) {
                        adminRepository.findByUserId(user.getId()).ifPresent(a -> {
                            response.put("id", a.getId()); // To będzie adminId dla profilu
                        });
                    } else if ("Student".equalsIgnoreCase(user.getRole())) {
                        studentRepository.findByUserId(user.getId()).ifPresent(s -> {
                            response.put("id", s.getId()); 
                            if (s.getGroup() != null) {
                                response.put("groupId", s.getGroup().getId());
                            }
                        });
                    } else if ("Teacher".equalsIgnoreCase(user.getRole())) {
                        teacherRepository.findByUserId(user.getId()).ifPresent(t -> {
                            response.put("id", t.getId());
                        });
                    }

                    return ResponseEntity.ok(response);
                } else {
                    return ResponseEntity.status(401).body("Invalid email or password");
                }
            })
            .orElse(ResponseEntity.status(401).body("Invalid email or password"));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        if (!userRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        userRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
