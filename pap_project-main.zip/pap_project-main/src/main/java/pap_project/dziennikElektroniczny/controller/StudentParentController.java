package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import java.util.List;

import pap_project.dziennikElektroniczny.entity.Student;
import pap_project.dziennikElektroniczny.entity.StudentParent;
import pap_project.dziennikElektroniczny.repository.ParentRepository;
import pap_project.dziennikElektroniczny.repository.StudentParentRepository;

@RestController
@RequestMapping("/api/studentParents")
public class StudentParentController {
    private final StudentParentRepository studentParentRepository;
    private final ParentRepository parentRepository;

    public StudentParentController(StudentParentRepository studentParentRepository, ParentRepository parentRepository) {
        this.studentParentRepository = studentParentRepository;
        this.parentRepository = parentRepository;
    }

    @GetMapping("/user/{userId}/children")
    public ResponseEntity<List<Student>> getChildrenByUserId(@PathVariable Long userId) {
        return parentRepository.findByUserId(userId)
            .map(parent -> {
                List<Student> children = studentParentRepository.findByParentId(parent.getId())
                    .stream()
                    .map(StudentParent::getStudent)
                    .collect(java.util.stream.Collectors.toList());
                return ResponseEntity.ok(children);
            })
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<StudentParent> getAllstudentParents() {
        return studentParentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<StudentParent> getStudentParentById(@PathVariable Long id) {
        return studentParentRepository.findById(id)
        .map(ResponseEntity::ok)
        .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createStudentParent(@RequestBody StudentParent studentParent) {
        if (studentParent.getStudent() == null || studentParent.getParent() == null) {
            return ResponseEntity.badRequest().body("Student ID and Parent ID are required.");
        }

        boolean exists = studentParentRepository.existsByStudentIdAndParentId(
            studentParent.getStudent().getId(),
            studentParent.getParent().getId()
        );

        if (exists) {
            return ResponseEntity.status(409).body("This student is already assigned to this parent.");
        }

        return ResponseEntity.ok(studentParentRepository.save(studentParent));
    }

    @PutMapping("/{id}")
    public ResponseEntity<StudentParent> updateStudentParent(@PathVariable Long id, @RequestBody StudentParent studentParentDetails) {
        return studentParentRepository.findById(id)
        .map(existingStudentParent -> {
            existingStudentParent.setParent(studentParentDetails.getParent());
            existingStudentParent.setStudent(studentParentDetails.getStudent());
            return ResponseEntity.ok(studentParentRepository.save(existingStudentParent));
        })
        .orElse(ResponseEntity.notFound().build());
        }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudentParent(@PathVariable Long id) {
        return studentParentRepository.findById(id)
        .map(studentParent -> {
            studentParentRepository.delete(studentParent);
            return ResponseEntity.ok().<Void>build();
        })
        .orElse(ResponseEntity.notFound().build());
    }
}