package pap_project.dziennikElektroniczny.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import pap_project.dziennikElektroniczny.entity.Subject;
import pap_project.dziennikElektroniczny.repository.SubjectRepository;
import pap_project.dziennikElektroniczny.repository.LessonRepository;
import pap_project.dziennikElektroniczny.repository.TeacherRepository;
import pap_project.dziennikElektroniczny.repository.GroupRepository;
import pap_project.dziennikElektroniczny.repository.GradeRepository;
import pap_project.dziennikElektroniczny.repository.RemarkRepository;
import pap_project.dziennikElektroniczny.repository.PresenceRepository;
import pap_project.dziennikElektroniczny.repository.TestRepository;

import java.time.LocalTime;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/subjects")
public class SubjectController {

    private final SubjectRepository subjectRepository;
    private final LessonRepository lessonRepository;
    private final TeacherRepository teacherRepository;
    private final GroupRepository groupRepository;
    private final GradeRepository gradeRepository;
    private final RemarkRepository remarkRepository;
    private final PresenceRepository presenceRepository;
    private final TestRepository testRepository;

    public SubjectController(
            SubjectRepository subjectRepository,
            LessonRepository lessonRepository,
            TeacherRepository teacherRepository,
            GroupRepository groupRepository,
            GradeRepository gradeRepository,
            RemarkRepository remarkRepository,
            PresenceRepository presenceRepository,
            TestRepository testRepository) {

        this.subjectRepository = subjectRepository;
        this.lessonRepository = lessonRepository;
        this.teacherRepository = teacherRepository;
        this.groupRepository = groupRepository;
        this.gradeRepository = gradeRepository;
        this.remarkRepository = remarkRepository;
        this.presenceRepository = presenceRepository;
        this.testRepository = testRepository;
    }

    @GetMapping
    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Subject> getSubjectById(@PathVariable Long id) {
        return subjectRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Transactional
    public ResponseEntity<?> createSubject(@RequestBody Map<String, Object> payload) {
        try {
            System.out.println("Otrzymany payload: " + payload);

            Subject subject = new Subject();
            
            Map<String, Object> lessonMap = (Map<String, Object>) payload.get("lesson");
            Map<String, Object> teacherMap = (Map<String, Object>) payload.get("teacher");
            Map<String, Object> groupMap = (Map<String, Object>) payload.get("group");

            if (lessonMap == null || teacherMap == null || groupMap == null) {
                return ResponseEntity.badRequest().body("Błąd: Brak danych lekcji, nauczyciela lub grupy w żądaniu.");
            }

            Long lessonId = Long.valueOf(lessonMap.get("id").toString());
            Long teacherId = Long.valueOf(teacherMap.get("id").toString());
            Long groupId = Long.valueOf(groupMap.get("id").toString());

            if (payload.get("startTime") == null || payload.get("endTime") == null) {
                return ResponseEntity.badRequest().body("Błąd: Brak godziny startu lub końca.");
            }
            
            boolean exists = subjectRepository.existsByGroupIdAndDayOfWeekAndStartTime(
                groupId, 
                payload.get("dayOfWeek").toString(), 
                LocalTime.parse(payload.get("startTime").toString())
            );

            if (exists) {
                return ResponseEntity.status(409).body("Taka lekcja już istnieje w planie!");
            }
            subject.setStartTime(LocalTime.parse(payload.get("startTime").toString()));
            subject.setEndTime(LocalTime.parse(payload.get("endTime").toString()));
            subject.setDayOfWeek(payload.get("dayOfWeek").toString());
            
            Object roomObj = payload.get("room");
            subject.setRoom(roomObj != null ? roomObj.toString() : "Sala ?");

            subject.setLesson(lessonRepository.findById(lessonId).orElseThrow());
            subject.setTeacher(teacherRepository.findById(teacherId).orElseThrow());
            subject.setGroup(groupRepository.findById(groupId).orElseThrow());

            return ResponseEntity.ok(subjectRepository.save(subject));
        } catch (Exception e) {
            e.printStackTrace(); 
            return ResponseEntity.badRequest().body("Błąd serwera: " + e.getMessage());
        }
    }

    @GetMapping("/group/{groupId}")
    public ResponseEntity<List<Subject>> getSubjectsByGroupId(@PathVariable Long groupId) {
        List<Subject> subjects = subjectRepository.findByGroupId(groupId);
        return ResponseEntity.ok(subjects);
    }

    @GetMapping("/teacher/{teacherId}")
    public ResponseEntity<List<Subject>> getSubjectsByTeacherId(@PathVariable Long teacherId) {
        List<Subject> subjects = subjectRepository.findByTeacherId(teacherId);
        return ResponseEntity.ok(subjects);
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<Subject> updateSubject(
            @PathVariable Long id,
            @RequestParam Long lessonId,
            @RequestParam Long teacherId,
            @RequestParam Long groupId,
            @RequestParam LocalTime startTime,
            @RequestParam LocalTime endTime,
            @RequestParam String dayOfWeek,
            @RequestParam String room) {

        return subjectRepository.findById(id)
                .map(existing -> {
                    existing.setLesson(lessonRepository.findById(lessonId).orElseThrow());
                    existing.setTeacher(teacherRepository.findById(teacherId).orElseThrow());
                    existing.setGroup(groupRepository.findById(groupId).orElseThrow());
                    existing.setStartTime(startTime);
                    existing.setEndTime(endTime);
                    existing.setDayOfWeek(dayOfWeek);
                    existing.setRoom(room);
                    return ResponseEntity.ok(subjectRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<?> deleteSubject(@PathVariable Long id) {
        return subjectRepository.findById(id).map(subject -> {
            Long groupId = subject.getGroup().getId();
            Long lessonId = subject.getLesson().getId();

            long otherOccurrences = subjectRepository.countByGroupIdAndLessonIdAndIdNot(groupId, lessonId, id);

            if (otherOccurrences == 0) {
                System.out.println("Ostatnia lekcja " + subject.getLesson().getName() + " dla grupy " + groupId + ". Usuwanie powiązanych danych...");
                
                gradeRepository.deleteByStudentGroupIdAndLessonId(groupId, lessonId);
                testRepository.deleteByGroupIdAndLessonId(groupId, lessonId);
                
                remarkRepository.deleteBySubjectId(id);
                
                presenceRepository.deleteBySubjectId(id);
            } else {
                System.out.println("Pozostały jeszcze inne lekcje " + subject.getLesson().getName() + ". Oceny i testy zostają.");
                
                remarkRepository.deleteBySubjectId(id);
                presenceRepository.deleteBySubjectId(id);
            }

            subjectRepository.delete(subject);
            
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/check-last")
    public ResponseEntity<Map<String, Boolean>> isLastOccurrence(@PathVariable Long id) {
        return subjectRepository.findById(id).map(subject -> {
            long others = subjectRepository.countByGroupIdAndLessonIdAndIdNot(
                subject.getGroup().getId(), 
                subject.getLesson().getId(), 
                id
            );
            return ResponseEntity.ok(Map.of("isLast", others == 0));
        }).orElse(ResponseEntity.notFound().build());
    }
}
