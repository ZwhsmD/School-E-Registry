package pap_project.dziennikElektroniczny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DziennikElektronicznyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DziennikElektronicznyApplication.class, args);
	}

}
