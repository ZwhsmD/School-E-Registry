package pap_project.dziennikElektroniczny.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "students_parents")
public class StudentParent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sp_id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "parent_id", nullable = false)
    private Parent parent;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;
}