package pap_project.dziennikElektroniczny.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "groups")
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "group_id")
    private Long id;
    @Column(name = "group_sign", nullable = false)
    private String groupSign;
    @Column(name = "group_number", nullable = false)
    private Long groupNumber;

    @OneToOne(optional = true)
    @JoinColumn(name = "class_tutor_id", nullable = false)
    private Teacher classTutor;

    @Column(name = "establishment_date", nullable = false)
    private LocalDate establishmentDate;
    @Column(name = "graduation_date", nullable = false)
    private LocalDate graduationDate;
}
