package pap_project.dziennikElektroniczny.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

// pap_project/dziennikElektroniczny/entity/Test.java

@Entity
@Data
@Table(name = "tests")
public class Test {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "test_id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "lesson_id", nullable = false)
    private Lesson lesson;

    @ManyToOne
    @JoinColumn(name = "group_id", nullable = false)
    private Group group;

    @Column(name = "test_date", nullable = false)
    private LocalDate testDate;

    @Column(nullable = false)
    private String name;
}