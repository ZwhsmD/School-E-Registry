package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByGroupId(Long groupId);
    List<Student> findBySurnameContainingIgnoreCase(String surname);
    boolean existsByGroupId(Long groupId);
    Optional<Student> findByUserId(Long userId);
}