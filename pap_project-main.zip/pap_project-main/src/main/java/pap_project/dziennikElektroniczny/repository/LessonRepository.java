package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LessonRepository extends JpaRepository<Lesson, Long> {
}
