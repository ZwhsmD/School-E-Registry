package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Parent;
import pap_project.dziennikElektroniczny.entity.StudentParent;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParentRepository extends JpaRepository<Parent, Long> {
    Optional<Parent> findByUserId(Long userId);
}
