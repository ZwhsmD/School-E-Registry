package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Group;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GroupRepository extends JpaRepository<Group, Long> {
    boolean existsByClassTutorId(Long tutorId);
}