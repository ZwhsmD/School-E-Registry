package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, Long> {
    List<Subject> findByTeacherId(Long teacherId);
    List<Subject> findByGroupId(Long groupId);
    List<Subject> findByDayOfWeek(String dayOfWeek);
    boolean existsByGroupIdAndDayOfWeekAndStartTime(Long groupId, String dayOfWeek, java.time.LocalTime startTime);
    boolean existsByTeacherId(Long teacherId);
    long countByGroupIdAndLessonIdAndIdNot(Long groupId, Long lessonId, Long id);
}