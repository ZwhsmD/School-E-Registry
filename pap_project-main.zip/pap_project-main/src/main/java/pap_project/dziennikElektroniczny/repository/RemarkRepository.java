package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Remark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RemarkRepository extends JpaRepository<Remark, Long> {
    List<Remark> findByStudentId(Long studentId);
    void deleteBySubjectId(Long subjectId);
}
