package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.StudentParent;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentParentRepository extends JpaRepository<StudentParent, Long> {
    boolean existsByStudentIdAndParentId(Long studentId, Long parentId);
    List<StudentParent> findByParentId(Long parentId);
}
