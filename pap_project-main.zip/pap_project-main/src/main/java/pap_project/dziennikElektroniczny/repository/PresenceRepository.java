package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Presence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PresenceRepository extends JpaRepository<Presence, Long> {
    List<Presence> findByStudentId(Long studentId);

    List<Presence> findByStudentIdAndSubjectId(Long studentId, Long subjectId);
    List<Presence> findBySubjectIdAndDate(Long subjectId, java.time.LocalDate date);
    List<Presence> findByStudentIdAndDate(Long studentId, java.time.LocalDate date);
    java.util.Optional<Presence> findByStudentIdAndSubjectIdAndDate(Long studentId, Long subjectId, java.time.LocalDate date);
    void deleteBySubjectId(Long subjectId);
}
