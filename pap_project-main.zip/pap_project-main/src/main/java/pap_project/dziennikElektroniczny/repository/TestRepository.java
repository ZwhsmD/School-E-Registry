package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Test;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TestRepository extends JpaRepository<Test, Long> {
    List<Test> findByGroupId(Long groupId);
    void deleteByGroupIdAndLessonId(Long groupId, Long lessonId);
}