package pap_project.dziennikElektroniczny.repository;

import pap_project.dziennikElektroniczny.entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByStudentIdAndLessonId(Long studentId, Long lessonId);
    List<Grade> findByStudentId(Long studentId);
    void deleteByStudentGroupIdAndLessonId(Long groupId, Long lessonId);
}