CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL NOT NULL CONSTRAINT pk_users PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL,
    CONSTRAINT chk_role CHECK (role IN ('Admin', 'Teacher', 'Parent', 'Student'))
);

CREATE TABLE IF NOT EXISTS admins (
    admin_id SERIAL NOT NULL CONSTRAINT pk_admins PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    CONSTRAINT fk_admins_users FOREIGN KEY ( user_id ) REFERENCES users ( user_id ) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS teachers (
    teacher_id SERIAL NOT NULL CONSTRAINT pk_teachers PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    gender TEXT NOT NULL,
    birth_date DATE NOT NULL,
    degree TEXT NOT NULL,
    CONSTRAINT chk_gender_teachers CHECK (gender = 'Male' OR gender = 'Female'),
    CONSTRAINT fk_teachers_users FOREIGN KEY ( user_id ) REFERENCES users ( user_id ) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS groups (
    group_id SERIAL NOT NULL CONSTRAINT pk_groups PRIMARY KEY,
    group_sign TEXT NOT NULL,
    group_number INTEGER NOT NULL,
    class_tutor_id INTEGER NOT NULL,
    establishment_date DATE NOT NULL,
    graduation_date DATE NOT NULL,
    CONSTRAINT uq_group_sign_number UNIQUE (group_sign, group_number),
    CONSTRAINT fk_class_tutor FOREIGN KEY ( class_tutor_id ) REFERENCES teachers ( teacher_id )
);

CREATE TABLE IF NOT EXISTS students (
    student_id SERIAL NOT NULL CONSTRAINT pk_students PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    gender TEXT NOT NULL,
    group_id INTEGER NOT NULL,
    birth_date DATE NOT NULL,
    admission_date DATE NOT NULL,
    CONSTRAINT fk_students_group FOREIGN KEY ( group_id ) REFERENCES groups ( group_id ),
    CONSTRAINT chk_gender_students CHECK (gender = 'Male' OR gender = 'Female'),
    CONSTRAINT fk_students_users FOREIGN KEY ( user_id ) REFERENCES users ( user_id ) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS parents (
    parent_id SERIAL NOT NULL CONSTRAINT pk_parents PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    name TEXT NOT NULL,
    surname TEXT NOT NULL,
    gender TEXT NOT NULL,
    birth_date DATE NOT NULL,
    CONSTRAINT chk_gender_parents CHECK (gender = 'Male' OR gender = 'Female'),
    CONSTRAINT fk_parents_users FOREIGN KEY ( user_id ) REFERENCES users ( user_id ) ON DELETE CASCADE
);

CREATE TABLE students_parents (
    sp_id SERIAL NOT NULL CONSTRAINT pk_students_parents PRIMARY KEY,
    parent_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    CONSTRAINT fk_sp_parent FOREIGN KEY ( parent_id ) REFERENCES parents ( parent_id ) ON DELETE CASCADE,
    CONSTRAINT fk_sp_student FOREIGN KEY ( student_id ) REFERENCES students ( student_id ) ON DELETE CASCADE,
    CONSTRAINT uq_students_parents UNIQUE (student_id, parent_id)
);

CREATE TABLE IF NOT EXISTS lessons (
    lesson_id SERIAL NOT NULL CONSTRAINT pk_lessons PRIMARY KEY,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS subjects (
    subject_id SERIAL NOT NULL CONSTRAINT pk_subjects PRIMARY KEY,
    lesson_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    day_of_week TEXT NOT NULL,
    room TEXT NOT NULL,
    CONSTRAINT fk_subjects_lesson FOREIGN KEY ( lesson_id ) REFERENCES lessons ( lesson_id ),
    CONSTRAINT fk_subjects_teacher FOREIGN KEY ( teacher_id ) REFERENCES teachers ( teacher_id ),
    CONSTRAINT fk_subjects_group FOREIGN KEY ( group_id ) REFERENCES groups ( group_id )
);

CREATE TABLE IF NOT EXISTS grades (
    grade_id SERIAL NOT NULL CONSTRAINT pk_grades PRIMARY KEY,
    student_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    lesson_id INTEGER NOT NULL,
    grade NUMERIC(2, 1) NOT NULL,
    weight INTEGER NOT NULL,
    description TEXT,
    CONSTRAINT fk_grades_student FOREIGN KEY ( student_id ) REFERENCES students ( student_id ) ON DELETE CASCADE,
    CONSTRAINT fk_grades_teacher FOREIGN KEY ( teacher_id ) REFERENCES teachers ( teacher_id ) ON DELETE CASCADE,
    CONSTRAINT fk_grades_lesson FOREIGN KEY ( lesson_id ) REFERENCES lessons ( lesson_id ) ON DELETE CASCADE,
    CONSTRAINT chk_grade CHECK (grade >= 1 AND grade <= 6),
    CONSTRAINT chk_weight CHECK (weight >= 1)
);

CREATE TABLE IF NOT EXISTS tests (
    test_id SERIAL NOT NULL CONSTRAINT pk_tests PRIMARY KEY,
    name TEXT NOT NULL,
    lesson_id INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    test_date DATE NOT NULL,
    CONSTRAINT fk_tests_lesson FOREIGN KEY ( lesson_id ) REFERENCES lessons ( lesson_id ) ON DELETE CASCADE,
    CONSTRAINT fk_tests_group FOREIGN KEY ( group_id ) REFERENCES groups ( group_id )
);

CREATE TABLE IF NOT EXISTS remarks (
    remark_id SERIAL NOT NULL CONSTRAINT pk_remarks PRIMARY KEY,
    student_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    description TEXT NOT NULL,
    date DATE NOT NULL,
    CONSTRAINT fk_remarks_student FOREIGN KEY ( student_id ) REFERENCES students ( student_id ) ON DELETE CASCADE,
    CONSTRAINT fk_remarks_teacher FOREIGN KEY ( teacher_id ) REFERENCES teachers ( teacher_id ),
    CONSTRAINT fk_remarks_subject FOREIGN KEY ( subject_id ) REFERENCES subjects ( subject_id ) ON DELETE CASCADE,
    CONSTRAINT chk_type_remarks CHECK (type = 'Positive' OR type = 'Negative')
);

CREATE TABLE IF NOT EXISTS presence (
    presence_id SERIAL NOT NULL CONSTRAINT pk_presence PRIMARY KEY,
    subject_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    date Date NOT NULL,
    type TEXT NOT NULL,
    CONSTRAINT fk_presence_subjects FOREIGN KEY ( subject_id ) REFERENCES subjects ( subject_id ) ON DELETE CASCADE,
    CONSTRAINT fk_presence_students FOREIGN KEY ( student_id ) REFERENCES students ( student_id ) ON DELETE CASCADE,
    CONSTRAINT chk_type_presence CHECK (type IN ('Absence', 'Lateness', 'Presence', 'Excused_Absence')),
    CONSTRAINT uq_student_presence_per_lesson UNIQUE ( student_id, subject_id, date )
);

INSERT INTO users (email, password_hash, role)
SELECT 'admin@pap.com', '$2a$12$YV.puxfQmyk8j1l/uaGArOaJ0TMqwL5sOnqgiY9ooeRZLqDQ.rp7K', 'Admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@pap.com');

INSERT INTO admins (user_id, name, surname)
SELECT user_id, 'Admin', 'Admin'
FROM users
WHERE email = 'admin@pap.com'
AND NOT EXISTS (SELECT 1 FROM admins a JOIN users u ON a.user_id = u.user_id WHERE u.email = 'admin@pap.com');


CREATE OR REPLACE FUNCTION oblicz_srednia_wazona(p_student_id INTEGER, p_lesson_id INTEGER)
RETURNS NUMERIC AS $$
DECLARE
    v_suma NUMERIC := 0;
    v_suma_wag NUMERIC := 0;
BEGIN
    SELECT SUM(grade * weight), SUM(weight)
    INTO v_suma, v_suma_wag
    FROM grades
    WHERE student_id = p_student_id AND lesson_id = p_lesson_id;

    IF v_suma_wag > 0 THEN
        RETURN ROUND(v_suma / v_suma_wag, 2);
    ELSE
        RETURN 0;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION czy_czerwony_pasek(p_student_id INTEGER)
RETURNS TEXT AS $$
DECLARE
    v_suma NUMERIC := 0;
    v_count INTEGER := 0;
    r_przedmiot RECORD;
BEGIN
    FOR r_przedmiot IN SELECT DISTINCT lesson_id FROM grades WHERE student_id = p_student_id
    LOOP
        v_suma := v_suma + oblicz_srednia_wazona(p_student_id, r_przedmiot.lesson_id::INTEGER);
        v_count := v_count + 1;
    END LOOP;

    IF v_count > 0 AND (v_suma / v_count) >= 4.75 THEN
        RETURN 'tak';
    ELSE
        RETURN 'nie';
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE promocja_do_klasy(p_group_id INTEGER)
AS $$
BEGIN
    UPDATE groups
    SET graduation_date = graduation_date + INTERVAL '12 months'
    WHERE group_id = p_group_id;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE usprawiedliw_okres(p_student_id INTEGER, p_data_od DATE, p_data_do DATE)
AS $$
BEGIN
    UPDATE presence
    SET type = 'Excused_Absence'
    WHERE student_id = p_student_id
      AND type = 'Absence'
      AND date BETWEEN p_data_od AND p_data_do;

    RAISE NOTICE 'Usprawiedliwiono nieobecnosci dla ucznia %', p_student_id;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION fn_chk_zakres_oceny()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.grade < 1 OR NEW.grade > 6 THEN
        RAISE EXCEPTION 'Ocena musi byc pomiedzy 1 a 6';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_chk_zakres_oceny
BEFORE INSERT OR UPDATE ON grades
FOR EACH ROW EXECUTE FUNCTION fn_chk_zakres_oceny();

CREATE OR REPLACE FUNCTION fn_sprawdz_kolizje_lekcji()
RETURNS TRIGGER AS $$
DECLARE
    v_counter INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_counter
    FROM subjects
    WHERE teacher_id = NEW.teacher_id
      AND day_of_week = NEW.day_of_week
      AND (
          (NEW.start_time >= start_time AND NEW.start_time < end_time) OR
          (NEW.end_time > start_time AND NEW.end_time <= end_time)
      );
    IF v_counter > 0 THEN
        RAISE EXCEPTION 'Nauczyciel ma juz zaplanowana inna lekcje w tym czasie.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sprawdz_kolizje_lekcji
BEFORE INSERT OR UPDATE ON subjects
FOR EACH ROW EXECUTE FUNCTION fn_sprawdz_kolizje_lekcji();