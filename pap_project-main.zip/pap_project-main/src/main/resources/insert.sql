INSERT INTO users (user_id, email, password_hash, role) VALUES 
(2, 'jkowadlo@pap.com', 'hash1', 'Teacher'),
(3, 'anowakowska@pap.com', 'hash2', 'Teacher'),
(4, 'pwisniewski@pap.com', 'hash3', 'Teacher'),
(5, 'mzajac@pap.com', 'hash4', 'Teacher'),
(6, 'sbatory@pap.com', 'hash5', 'Teacher');

INSERT INTO teachers (teacher_id, user_id, name, surname, gender, birth_date, degree) VALUES 
(1, 2, 'Jan', 'Kowadlo', 'Male', '1975-03-12', 'Magister'),
(2, 3, 'Anna', 'Nowakowska', 'Female', '1982-05-20', 'Doktor'),
(3, 4, 'Piotr', 'Wisniewski', 'Male', '1970-11-02', 'Magister'),
(4, 5, 'Maria', 'Zajac', 'Female', '1988-07-15', 'Magister'),
(5, 6, 'Stefan', 'Batory', 'Male', '1965-01-30', 'Magister');

INSERT INTO groups (group_id, group_sign, group_number, class_tutor_id, establishment_date, graduation_date) VALUES 
(1, 'A', 2, 1, '2025-09-01', '2028-06-30'),
(2, 'B', 3, 2, '2025-09-01', '2028-06-30'),
(3, 'C', 4, 3, '2025-09-01', '2028-06-30');

INSERT INTO lessons (lesson_id, name) VALUES 
(1, 'Matematyka'), 
(2, 'Polski'), 
(3, 'Angielski'), 
(4, 'Historia'), 
(5, 'Geografia');

INSERT INTO subjects (subject_id, lesson_id, teacher_id, group_id, start_time, end_time, day_of_week, room) VALUES 
(1, 1, 1, 1, '08:00', '08:45', 'Poniedziałek', '101'),
(2, 2, 2, 1, '09:00', '09:45', 'Wtorek', '102'),
(3, 3, 3, 2, '08:00', '08:45', 'Środa', '201'),
(4, 4, 4, 2, '09:00', '09:45', 'Środa', '202'),
(5, 5, 5, 3, '10:00', '10:45', 'Czwartek', '301');

INSERT INTO users (user_id, email, password_hash, role) VALUES 
(7, 'jkowalski@pap.com', 'h7', 'Student'), (8, 'anowak@pap.com', 'h8', 'Student'),
(9, 'mwisniewski@pap.com', 'h9', 'Student'), (10, 'kwojcik@pap.com', 'h10', 'Student'),
(11, 'tkowalczyk@pap.com', 'h11', 'Student');

INSERT INTO users (user_id, email, password_hash, role) VALUES 
(12, 'pmazur@pap.com', 'h12', 'Student'), (13, 'alewandowska@pap.com', 'h13', 'Student'),
(14, 'jzielinski@pap.com', 'h14', 'Student'), (15, 'mszymanska@pap.com', 'h15', 'Student'),
(16, 'mwozniak@pap.com', 'h16', 'Student');

INSERT INTO users (user_id, email, password_hash, role) VALUES 
(17, 'pkozlowski@pap.com', 'h17', 'Student'), (18, 'ajankowska@pap.com', 'h18', 'Student'),
(19, 'mkwiatkowski@pap.com', 'h19', 'Student'), (20, 'zmazurek@pap.com', 'h20', 'Student'),
(21, 'abartczak@pap.com', 'h21', 'Student');

INSERT INTO students (student_id, user_id, name, surname, gender, group_id, birth_date, admission_date) VALUES 
(7, 7, 'Jan', 'Kowalski', 'Male', 1, '2010-01-12', '2025-09-01'),
(8, 8, 'Anna', 'Nowak', 'Female', 1, '2010-02-15', '2025-09-01'),
(9, 9, 'Mateusz', 'Wiśniewski', 'Male', 1, '2010-03-20', '2025-09-01'),
(10, 10, 'Katarzyna', 'Wójcik', 'Female', 1, '2010-04-05', '2025-09-01'),
(11, 11, 'Tomasz', 'Kowalczyk', 'Male', 1, '2010-05-30', '2025-09-01');

-- Klasa 3B
INSERT INTO students (student_id, user_id, name, surname, gender, group_id, birth_date, admission_date) VALUES 
(12, 12, 'Piotr', 'Mazur', 'Male', 2, '2010-06-11', '2025-09-01'),
(13, 13, 'Alicja', 'Lewandowska', 'Female', 2, '2010-07-22', '2025-09-01'),
(14, 14, 'Jakub', 'Zieliński', 'Male', 2, '2010-08-14', '2025-09-01'),
(15, 15, 'Małgorzata', 'Szymańska', 'Female', 2, '2010-09-01', '2025-09-01'),
(16, 16, 'Michał', 'Woźniak', 'Male', 2, '2010-10-18', '2025-09-01');

-- Klasa 4C
INSERT INTO students (student_id, user_id, name, surname, gender, group_id, birth_date, admission_date) VALUES 
(17, 17, 'Paweł', 'Kozłowski', 'Male', 3, '2010-11-05', '2025-09-01'),
(18, 18, 'Agata', 'Jankowska', 'Female', 3, '2010-12-24', '2025-09-01'),
(19, 19, 'Mikołaj', 'Kwiatkowski', 'Male', 3, '2011-01-15', '2025-09-01'),
(20, 20, 'Zofia', 'Mazurek', 'Female', 3, '2011-02-10', '2025-09-01'),
(21, 21, 'Antoni', 'Bartczak', 'Male', 3, '2011-03-03', '2025-09-01');

INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 7, '2026-01-15', 'Absence'), (1, 8, '2026-01-15', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 9, '2026-01-16', 'Absence'), (1, 10, '2026-01-16', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 11, '2026-01-19', 'Absence'), (1, 12, '2026-01-19', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 13, '2026-01-20', 'Absence'), (1, 14, '2026-01-20', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 15, '2026-01-21', 'Absence'), (1, 16, '2026-01-21', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 17, '2026-01-22', 'Absence'), (1, 18, '2026-01-22', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 19, '2026-01-23', 'Absence'), (1, 20, '2026-01-23', 'Absence');
INSERT INTO presence (subject_id, student_id, date, type) VALUES (1, 21, '2026-01-26', 'Absence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 9, '2026-01-15', 'Presence'), (1, 10, '2026-01-15', 'Presence'), (1, 11, '2026-01-15', 'Presence'),
(1, 12, '2026-01-15', 'Presence'), (1, 13, '2026-01-15', 'Presence'), (1, 14, '2026-01-15', 'Presence'),
(1, 15, '2026-01-15', 'Presence'), (1, 16, '2026-01-15', 'Presence'), (1, 17, '2026-01-15', 'Presence'),
(1, 18, '2026-01-15', 'Presence'), (1, 19, '2026-01-15', 'Presence'), (1, 20, '2026-01-15', 'Presence'),
(1, 21, '2026-01-15', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-16', 'Presence'), (1, 8, '2026-01-16', 'Presence'), (1, 11, '2026-01-16', 'Presence'),
(1, 12, '2026-01-16', 'Presence'), (1, 13, '2026-01-16', 'Presence'), (1, 14, '2026-01-16', 'Presence'),
(1, 15, '2026-01-16', 'Presence'), (1, 16, '2026-01-16', 'Presence'), (1, 17, '2026-01-16', 'Presence'),
(1, 18, '2026-01-16', 'Presence'), (1, 19, '2026-01-16', 'Presence'), (1, 20, '2026-01-16', 'Presence'),
(1, 21, '2026-01-16', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-19', 'Presence'), (1, 8, '2026-01-19', 'Presence'), (1, 9, '2026-01-19', 'Presence'),
(1, 10, '2026-01-19', 'Presence'), (1, 13, '2026-01-19', 'Presence'), (1, 14, '2026-01-19', 'Presence'),
(1, 15, '2026-01-19', 'Presence'), (1, 16, '2026-01-19', 'Presence'), (1, 17, '2026-01-19', 'Presence'),
(1, 18, '2026-01-19', 'Presence'), (1, 19, '2026-01-19', 'Presence'), (1, 20, '2026-01-19', 'Presence'),
(1, 21, '2026-01-19', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-20', 'Presence'), (1, 8, '2026-01-20', 'Presence'), (1, 9, '2026-01-20', 'Presence'),
(1, 10, '2026-01-20', 'Presence'), (1, 11, '2026-01-20', 'Presence'), (1, 12, '2026-01-20', 'Presence'),
(1, 15, '2026-01-20', 'Presence'), (1, 16, '2026-01-20', 'Presence'), (1, 17, '2026-01-20', 'Presence'),
(1, 18, '2026-01-20', 'Presence'), (1, 19, '2026-01-20', 'Presence'), (1, 20, '2026-01-20', 'Presence'),
(1, 21, '2026-01-20', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-21', 'Presence'), (1, 8, '2026-01-21', 'Presence'), (1, 9, '2026-01-21', 'Presence'),
(1, 10, '2026-01-21', 'Presence'), (1, 11, '2026-01-21', 'Presence'), (1, 12, '2026-01-21', 'Presence'),
(1, 13, '2026-01-21', 'Presence'), (1, 14, '2026-01-21', 'Presence'), (1, 17, '2026-01-21', 'Presence'),
(1, 18, '2026-01-21', 'Presence'), (1, 19, '2026-01-21', 'Presence'), (1, 20, '2026-01-21', 'Presence'),
(1, 21, '2026-01-21', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-22', 'Presence'), (1, 8, '2026-01-22', 'Presence'), (1, 9, '2026-01-22', 'Presence'),
(1, 10, '2026-01-22', 'Presence'), (1, 11, '2026-01-22', 'Presence'), (1, 12, '2026-01-22', 'Presence'),
(1, 13, '2026-01-22', 'Presence'), (1, 14, '2026-01-22', 'Presence'), (1, 15, '2026-01-22', 'Presence'),
(1, 16, '2026-01-22', 'Presence'), (1, 19, '2026-01-22', 'Presence'), (1, 20, '2026-01-22', 'Presence'),
(1, 21, '2026-01-22', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-23', 'Presence'), (1, 8, '2026-01-23', 'Presence'), (1, 9, '2026-01-23', 'Presence'),
(1, 10, '2026-01-23', 'Presence'), (1, 11, '2026-01-23', 'Presence'), (1, 12, '2026-01-23', 'Presence'),
(1, 13, '2026-01-23', 'Presence'), (1, 14, '2026-01-23', 'Presence'), (1, 15, '2026-01-23', 'Presence'),
(1, 16, '2026-01-23', 'Presence'), (1, 17, '2026-01-23', 'Presence'), (1, 18, '2026-01-23', 'Presence'),
(1, 21, '2026-01-23', 'Presence');

INSERT INTO presence (subject_id, student_id, date, type) VALUES 
(1, 7, '2026-01-26', 'Presence'), (1, 8, '2026-01-26', 'Presence'), (1, 9, '2026-01-26', 'Presence'),
(1, 10, '2026-01-26', 'Presence'), (1, 11, '2026-01-26', 'Presence'), (1, 12, '2026-01-26', 'Presence'),
(1, 13, '2026-01-26', 'Presence'), (1, 14, '2026-01-26', 'Presence'), (1, 15, '2026-01-26', 'Presence'),
(1, 16, '2026-01-26', 'Presence'), (1, 17, '2026-01-26', 'Presence'), (1, 18, '2026-01-26', 'Presence'),
(1, 19, '2026-01-26', 'Presence'), (1, 20, '2026-01-26', 'Presence');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(7,3,3,6,2,'Past Perfect quiz'), (7,3,3,5,3,'Presentation'),
(8,3,3,5,2,'Past Perfect quiz'), (8,3,3,6,3,'Presentation'),
(9,3,3,4,2,'Past Perfect quiz'), (9,3,3,5,3,'Presentation'),
(10,3,3,6,2,'Past Perfect quiz'), (10,3,3,6,3,'Presentation'),
(11,3,3,5,2,'Past Perfect quiz'), (11,3,3,4,3,'Presentation');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(12,3,3,4,2,'Conditional Sentences'), (12,3,3,4,3,'Listening Test'),
(13,3,3,6,2,'Conditional Sentences'), (13,3,3,5,3,'Listening Test'),
(14,3,3,5,2,'Conditional Sentences'), (14,3,3,5,3,'Listening Test'),
(15,3,3,6,2,'Conditional Sentences'), (15,3,3,6,3,'Listening Test'),
(16,3,3,4,2,'Conditional Sentences'), (16,3,3,4,3,'Listening Test');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(17,3,3,5,2,'Business English'), (17,3,3,5,3,'Essay Writing'),
(18,3,3,6,2,'Business English'), (18,3,3,6,3,'Essay Writing'),
(19,3,3,5,2,'Business English'), (19,3,3,5,3,'Essay Writing'),
(20,3,3,4,2,'Business English'), (20,3,3,5,3,'Essay Writing'),
(21,3,3,6,2,'Business English'), (21,3,3,6,3,'Essay Writing');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(7,1,1,4,3,'planimetria sprawdzian'), (7,1,1,5,2,'wielomiany kartkówka'),
(8,1,1,3,3,'planimetria sprawdzian'), (8,1,1,4,2,'wielomiany kartkówka'),
(9,1,1,5,3,'planimetria sprawdzian'), (9,1,1,6,2,'wielomiany kartkówka'),
(10,1,1,2,3,'planimetria sprawdzian'), (10,1,1,3,2,'wielomiany kartkówka'),
(11,1,1,4,3,'planimetria sprawdzian'), (11,1,1,4,2,'wielomiany kartkówka');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(12,1,1,5,3,'Funkcja wykladnicza'), (12,1,1,5,2,'Rachunek rozniczkowy'),
(13,1,1,3,3,'Funkcja wykladnicza'), (13,1,1,2,2,'Rachunek rozniczkowy'),
(14,1,1,6,3,'Funkcja wykladnicza'), (14,1,1,5,2,'Rachunek rozniczkowy'),
(15,1,1,4,3,'Funkcja wykladnicza'), (15,1,1,3,2,'Rachunek rozniczkowy'),
(16,1,1,5,3,'Funkcja wykladnicza'), (16,1,1,4,2,'Rachunek rozniczkowy');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(17,1,1,3,3,'Geometria analityczna'), (17,1,1,4,2,'Logarytmy klasowka'),
(18,1,1,5,3,'Geometria analityczna'), (18,1,1,5,2,'Logarytmy klasowka'),
(19,1,1,4,3,'Geometria analityczna'), (19,1,1,6,2,'Logarytmy klasowka'),
(20,1,1,2,3,'Geometria analityczna'), (20,1,1,3,2,'Logarytmy klasowka'),
(21,1,1,5,3,'Geometria analityczna'), (21,1,1,5,2,'Logarytmy klasowka');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(7,2,2,5,4,'Romantyzm - Pan Tadeusz'), (7,2,2,4,2,'Liryka - sprawdzian'),
(8,2,2,4,4,'Romantyzm - Pan Tadeusz'), (8,2,2,3,2,'Liryka - sprawdzian'),
(9,2,2,6,4,'Romantyzm - Pan Tadeusz'), (9,2,2,5,2,'Liryka - sprawdzian'),
(10,2,2,3,4,'Romantyzm - Pan Tadeusz'), (10,2,2,4,2,'Liryka - sprawdzian'),
(11,2,2,5,4,'Romantyzm - Pan Tadeusz'), (11,2,2,5,2,'Liryka - sprawdzian');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(12,2,2,4,4,'Pozytywizm - Lalka'), (12,2,2,3,2,'Analiza wiersza - kartkowka'),
(13,2,2,5,4,'Pozytywizm - Lalka'), (13,2,2,6,2,'Analiza wiersza - kartkowka'),
(14,2,2,4,4,'Pozytywizm - Lalka'), (14,2,2,4,2,'Analiza wiersza - kartkowka'),
(15,2,2,3,4,'Pozytywizm - Lalka'), (15,2,2,3,2,'Analiza wiersza - kartkowka'),
(16,2,2,5,4,'Pozytywizm - Lalka'), (16,2,2,5,2,'Analiza wiersza - kartkowka');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(17,2,2,6,4,'Mloda Polska - Wesele'), (17,2,2,6,2,'Interpretacja tekstu'),
(18,2,2,4,4,'Mloda Polska - Wesele'), (18,2,2,4,2,'Interpretacja tekstu'),
(19,2,2,5,4,'Mloda Polska - Wesele'), (19,2,2,4,2,'Interpretacja tekstu'),
(20,2,2,3,4,'Mloda Polska - Wesele'), (20,2,2,2,2,'Interpretacja tekstu'),
(21,2,2,5,4,'Mloda Polska - Wesele'), (21,2,2,5,2,'Interpretacja tekstu');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(7,4,4,3,2,'Starozytny Rzym - test'), (7,4,4,4,4,'Sredniowiecze w Europie'),
(8,4,4,4,2,'Starozytny Rzym - test'), (8,4,4,5,4,'Sredniowiecze w Europie'),
(9,4,4,5,2,'Starozytny Rzym - test'), (9,4,4,4,4,'Sredniowiecze w Europie'),
(10,4,4,2,2,'Starozytny Rzym - test'), (10,4,4,3,4,'Sredniowiecze w Europie'),
(11,4,4,4,2,'Starozytny Rzym - test'), (11,4,4,4,4,'Sredniowiecze w Europie');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(12,4,4,5,2,'Nowozytnosc - odkrycia'), (12,4,4,5,4,'Rewolucja Francuska - spr'),
(13,4,4,3,2,'Nowozytnosc - odkrycia'), (13,4,4,4,4,'Rewolucja Francuska - spr'),
(14,4,4,6,2,'Nowozytnosc - odkrycia'), (14,4,4,6,4,'Rewolucja Francuska - spr'),
(15,4,4,4,2,'Nowozytnosc - odkrycia'), (15,4,4,4,4,'Rewolucja Francuska - spr'),
(16,4,4,5,2,'Nowozytnosc - odkrycia'), (16,4,4,5,4,'Rewolucja Francuska - spr');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(17,4,4,3,2,'I Wojna Swiatowa - quiz'), (17,4,4,4,4,'II Rzeczpospolita - spr'),
(18,4,4,4,2,'I Wojna Swiatowa - quiz'), (18,4,4,5,4,'II Rzeczpospolita - spr'),
(19,4,4,5,2,'I Wojna Swiatowa - quiz'), (19,4,4,5,4,'II Rzeczpospolita - spr'),
(20,4,4,2,2,'I Wojna Swiatowa - quiz'), (20,4,4,2,4,'II Rzeczpospolita - spr'),
(21,4,4,4,2,'I Wojna Swiatowa - quiz'), (21,4,4,4,4,'II Rzeczpospolita - spr');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(7,5,5,5,3,'Rolnictwo w Polsce'), (7,5,5,4,2,'Panstwa Europy - spr'),
(8,5,5,4,3,'Rolnictwo w Polsce'), (8,5,5,3,2,'Panstwa Europy - spr'),
(9,5,5,6,3,'Rolnictwo w Polsce'), (9,5,5,5,2,'Panstwa Europy - spr'),
(10,5,5,3,3,'Rolnictwo w Polsce'), (10,5,5,4,2,'Panstwa Europy - spr'),
(11,5,5,5,3,'Rolnictwo w Polsce'), (11,5,5,5,2,'Panstwa Europy - spr');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(12,5,5,4,3,'Hydrosfera - sprawdzian'), (12,5,5,4,2,'Azja - gospodarka'),
(13,5,5,5,3,'Hydrosfera - sprawdzian'), (13,5,5,6,2,'Azja - gospodarka'),
(14,5,5,5,3,'Hydrosfera - sprawdzian'), (14,5,5,5,2,'Azja - gospodarka'),
(15,5,5,4,3,'Hydrosfera - sprawdzian'), (15,5,5,3,2,'Azja - gospodarka'),
(16,5,5,5,3,'Hydrosfera - sprawdzian'), (16,5,5,4,2,'Azja - gospodarka');

INSERT INTO grades (student_id, teacher_id, lesson_id, grade, weight, description) VALUES 
(17,5,5,4,3,'Atmosfera i klimat'), (17,5,5,5,2,'Ameryka Polnocna - spr'),
(18,5,5,6,3,'Atmosfera i klimat'), (18,5,5,6,2,'Ameryka Polnocna - spr'),
(19,5,5,5,3,'Atmosfera i klimat'), (19,5,5,4,2,'Ameryka Polnocna - spr'),
(20,5,5,3,3,'Atmosfera i klimat'), (20,5,5,2,2,'Ameryka Polnocna - spr'),
(21,5,5,5,3,'Atmosfera i klimat'), (21,5,5,5,2,'Ameryka Polnocna - spr');

INSERT INTO tests (name, lesson_id, group_id, test_date) VALUES 
('Sprawdzian - Trygonometria', 1, 1, '2026-02-10'),
('Sprawdzian - Romantyzm', 2, 1, '2026-02-12'),
('Sprawdzian - Past Perfect', 3, 1, '2026-02-15'),
('Sprawdzian - Starozytnosc', 4, 1, '2026-02-18'),
('Sprawdzian - Rolnictwo', 5, 1, '2026-02-20');

INSERT INTO tests (name, lesson_id, group_id, test_date) VALUES 
('Sprawdzian - Ciagi liczbowe', 1, 2, '2026-02-11'),
('Sprawdzian - Pozytywizm', 2, 2, '2026-02-13'),
('Sprawdzian - Conditionals', 3, 2, '2026-02-16'),
('Sprawdzian - Nowozytnosc', 4, 2, '2026-02-19'),
('Sprawdzian - Hydrosfera', 5, 2, '2026-02-21');

INSERT INTO tests (name, lesson_id, group_id, test_date) VALUES 
('Sprawdzian - Wielomiany', 1, 3, '2026-02-12'),
('Sprawdzian - Mloda Polska', 2, 3, '2026-02-14'),
('Sprawdzian - Business English', 3, 3, '2026-02-17'),
('Sprawdzian - I Wojna Swiatowa', 4, 3, '2026-02-20'),
('Sprawdzian - Atmosfera', 5, 3, '2026-02-22');

INSERT INTO users (user_id, email, password_hash, role) VALUES 
(22, 'mkowalski-parent@pap.com', 'p22', 'Parent'),
(23, 'enowak-parent@pap.com', 'p23', 'Parent'),
(24, 'rwisniewski-parent@pap.com', 'p24', 'Parent'),
(25, 'bwojcik-parent@pap.com', 'p25', 'Parent'),
(26, 'akowalczyk-parent@pap.com', 'p26', 'Parent'),
(27, 'kmazur-parent@pap.com', 'p27', 'Parent'),
(28, 'mlewandowska-parent@pap.com', 'p28', 'Parent'),
(29, 'dzielinski-parent@pap.com', 'p29', 'Parent'),
(30, 'bszymanska-parent@pap.com', 'p30', 'Parent'),
(31, 'twozniak-parent@pap.com', 'p31', 'Parent'),
(32, 'akozlowski-parent@pap.com', 'p32', 'Parent'),
(33, 'jjankowska-parent@pap.com', 'p33', 'Parent'),
(34, 'pkwiatkowski-parent@pap.com', 'p34', 'Parent'),
(35, 'mmazurek-parent@pap.com', 'p35', 'Parent'),
(36, 'jbartczak-parent@pap.com', 'p36', 'Parent');

INSERT INTO parents (parent_id, user_id, name, surname, gender, birth_date) VALUES 
(1, 22, 'Marek', 'Kowalski', 'Male', '1985-04-10'),
(2, 23, 'Ewa', 'Nowak', 'Female', '1986-05-15'),
(3, 24, 'Robert', 'Wiśniewski', 'Male', '1983-11-20'),
(4, 25, 'Beata', 'Wójcik', 'Female', '1987-01-05'),
(5, 26, 'Adam', 'Kowalczyk', 'Male', '1984-08-30'),
(6, 27, 'Krzysztof', 'Mazur', 'Male', '1982-06-11'),
(7, 28, 'Magdalena', 'Lewandowska', 'Female', '1988-03-22'),
(8, 29, 'Dariusz', 'Zieliński', 'Male', '1981-09-14'),
(9, 30, 'Barbara', 'Szymańska', 'Female', '1985-12-01'),
(10, 31, 'Tomasz', 'Woźniak', 'Male', '1980-02-18'),
(11, 32, 'Andrzej', 'Kozłowski', 'Male', '1979-11-05'),
(12, 33, 'Joanna', 'Jankowska', 'Female', '1984-05-24'),
(13, 34, 'Piotr', 'Kwiatkowski', 'Male', '1982-10-15'),
(14, 35, 'Monika', 'Mazurek', 'Female', '1987-04-10'),
(15, 36, 'Jacek', 'Bartczak', 'Male', '1983-07-03');

INSERT INTO students_parents (parent_id, student_id) VALUES 
(1, 7), (2, 8), (3, 9), (4, 10), (5, 11), 
(6, 12), (7, 13), (8, 14), (9, 15), (10, 16), 
(11, 17), (12, 18), (13, 19), (14, 20), (15, 21); 